export const COLLEGES = [
  "Faculty of Arts",
  "Faculty of Science",
  "Faculty of Engineering",
  "Faculty of Medicine",
  "Faculty of Business",
  "Faculty of Law",
  "Faculty of Education",
  "Faculty of Computer Science",
];

export const LEVELS = ["1", "2", "3", "4", "5", "6", "7", "8"];

export const YEARS = [2022, 2023, 2024, 2025, 2026];