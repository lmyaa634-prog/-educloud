import { useState, useRef } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/feature/Navbar";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";
import { COLLEGES, LEVELS, YEARS } from "@/mocks/searchData";

const ACCEPTED_TYPES = ".pdf,.ppt,.pptx,.doc,.docx,.jpg,.jpeg,.png,.mp4,.mov";
const MAX_FILE_SIZE_MB = 50;

interface UploadForm {
  courseName: string;
  instructor: string;
  college: string;
  year: string;
  level: string;
  description: string;
}

export default function UploadPage() {
  const { user } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [form, setForm] = useState<UploadForm>({
    courseName: "",
    instructor: "",
    college: "",
    year: "",
    level: "",
    description: "",
  });
  const [errors, setErrors] = useState<Partial<UploadForm & { file: string }>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getFileType = (f: File): string => {
    const ext = f.name.split(".").pop()?.toLowerCase() || "";
    if (ext === "pdf") return "pdf";
    if (["ppt", "pptx"].includes(ext)) return "ppt";
    if (["doc", "docx"].includes(ext)) return "docx";
    if (["jpg", "jpeg", "png", "gif"].includes(ext)) return "image";
    if (["mp4", "mov", "avi"].includes(ext)) return "video";
    return "other";
  };

  const FILE_TYPE_CONFIG: Record<string, { icon: string; color: string; bg: string; label: string }> = {
    pdf: { icon: "ri-file-pdf-line", color: "text-red-600", bg: "bg-red-50", label: "PDF Document" },
    ppt: { icon: "ri-file-ppt-line", color: "text-orange-600", bg: "bg-orange-50", label: "PowerPoint" },
    docx: { icon: "ri-file-word-line", color: "text-sky-600", bg: "bg-sky-50", label: "Word Document" },
    image: { icon: "ri-image-line", color: "text-violet-600", bg: "bg-violet-50", label: "Image" },
    video: { icon: "ri-video-line", color: "text-pink-600", bg: "bg-pink-50", label: "Video" },
    other: { icon: "ri-file-line", color: "text-gray-600", bg: "bg-gray-50", label: "File" },
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped) validateAndSetFile(dropped);
  };

  const validateAndSetFile = (f: File) => {
    if (f.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
      setErrors((prev) => ({ ...prev, file: `File size must be under ${MAX_FILE_SIZE_MB}MB.` }));
      return;
    }
    setErrors((prev) => ({ ...prev, file: undefined }));
    setFile(f);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) validateAndSetFile(f);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors((prev) => ({ ...prev, [e.target.name]: undefined }));
  };

  const validate = () => {
    const newErrors: Partial<UploadForm & { file: string }> = {};
    if (!file) newErrors.file = "Please select a file to upload.";
    if (!form.courseName.trim()) newErrors.courseName = "Course name is required.";
    if (!form.instructor.trim()) newErrors.instructor = "Instructor name is required.";
    if (!form.college) newErrors.college = "Please select a college.";
    if (!form.year) newErrors.year = "Please select a year.";
    if (!form.level) newErrors.level = "Please select an academic level.";
    return newErrors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors = validate();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    if (!user || !file) return;

    setSubmitting(true);

    // 1. Upload file to Supabase Storage
    const timestamp = Date.now();
    const cleanName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const filePath = `${user.id}/${timestamp}_${cleanName}`;

    const { error: uploadError } = await supabase.storage
      .from("file_storage")
      .upload(filePath, file, { upsert: false });

    if (uploadError) {
      setErrors((prev) => ({ ...prev, file: `Upload failed: ${uploadError.message}` }));
      setSubmitting(false);
      return;
    }

    // 2. Extract level number from string like "1st Year"
    const levelNum = parseInt(form.level, 10);
    const yearNum = parseInt(form.year, 10);

    // 3. Insert metadata into files table
    const { error: dbError } = await supabase.from("files").insert({
      title: file.name,
      description: form.description.trim() || null,
      file_url: filePath,
      file_type: getFileType(file),
      course_name: form.courseName.trim(),
      instructor_name: form.instructor.trim() || null,
      college: form.college,
      year: Number.isNaN(yearNum) ? null : yearNum,
      level: Number.isNaN(levelNum) ? null : levelNum,
      uploader_id: user.id,
      status: "pending",
      likes: 0,
      stars_avg: 0,
      views: 0,
    });

    if (dbError) {
      setErrors((prev) => ({ ...prev, file: `Database error: ${dbError.message}` }));
      setSubmitting(false);
      return;
    }

    setSubmitting(false);
    setSubmitted(true);
  };

  const fileType = file ? getFileType(file) : null;
  const typeConfig = fileType ? FILE_TYPE_CONFIG[fileType] : null;

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <div className="bg-white rounded-xl border border-gray-100 p-12">
            <div className="w-16 h-16 flex items-center justify-center mx-auto mb-5 bg-sky-50 rounded-full">
              <i className="ri-upload-cloud-2-line text-sky-500 text-3xl"></i>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">File Submitted!</h2>
            <p className="text-gray-500 mb-2">
              Your file <strong className="text-gray-700">&ldquo;{file?.name}&rdquo;</strong> has been uploaded successfully.
            </p>
            <p className="text-sm text-gray-400 mb-8">
              It is now pending admin review. Once approved, it will appear on the platform for others to discover.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                to="/"
                className="px-6 py-2.5 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
              >
                Back to Home
              </Link>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setFile(null);
                  setForm({ courseName: "", instructor: "", college: "", year: "", level: "", description: "" });
                  setErrors({});
                }}
                className="px-6 py-2.5 border border-gray-200 text-gray-700 hover:bg-gray-50 text-sm font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
              >
                Upload Another File
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="bg-sky-600 py-8">
        <div className="max-w-4xl mx-auto px-4 md:px-6">
          <h1 className="text-white font-bold text-2xl mb-1">Upload Academic Material</h1>
          <p className="text-sky-200 text-sm">
            Share your notes, slides, or summaries with your peers. Files are reviewed before publishing.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 md:px-6 py-8">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 flex flex-col gap-6">
              <div className="bg-white rounded-lg border border-gray-100 p-6">
                <h2 className="font-semibold text-gray-900 mb-4">Select File</h2>
                <div
                  onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={handleFileDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all ${
                    dragOver
                      ? "border-sky-400 bg-sky-50"
                      : file
                      ? "border-sky-300 bg-sky-50/50"
                      : "border-gray-200 hover:border-sky-300 hover:bg-gray-50"
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept={ACCEPTED_TYPES}
                    onChange={handleFileInput}
                    className="hidden"
                  />
                  {file && typeConfig ? (
                    <div className="flex flex-col items-center">
                      <div className={`w-14 h-14 flex items-center justify-center rounded-xl mb-3 ${typeConfig.bg}`}>
                        <i className={`${typeConfig.icon} ${typeConfig.color} text-3xl`}></i>
                      </div>
                      <p className="font-medium text-gray-900 text-sm mb-0.5">{file.name}</p>
                      <p className="text-xs text-gray-500">
                        {typeConfig.label} &middot; {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                      <button
                        type="button"
                        onClick={(ev) => { ev.stopPropagation(); setFile(null); }}
                        className="mt-3 text-xs text-red-500 hover:text-red-700 cursor-pointer"
                      >
                        Remove file
                      </button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center">
                      <div className="w-14 h-14 flex items-center justify-center rounded-xl mb-3 bg-gray-100">
                        <i className="ri-upload-cloud-2-line text-gray-400 text-3xl"></i>
                      </div>
                      <p className="font-medium text-gray-700 text-sm mb-1">
                        Drop your file here or click to browse
                      </p>
                      <p className="text-xs text-gray-400">
                        PDF, PPT, DOCX, Images, Videos &middot; Max {MAX_FILE_SIZE_MB}MB
                      </p>
                    </div>
                  )}
                </div>
                {errors.file && <p className="text-xs text-red-500 mt-2">{errors.file}</p>}

                <div className="flex flex-wrap gap-2 mt-4">
                  {[
                    { label: "PDF", icon: "ri-file-pdf-line", color: "text-red-500" },
                    { label: "PPT", icon: "ri-file-ppt-line", color: "text-orange-500" },
                    { label: "DOCX", icon: "ri-file-word-line", color: "text-sky-500" },
                    { label: "Image", icon: "ri-image-line", color: "text-violet-500" },
                    { label: "Video", icon: "ri-video-line", color: "text-pink-500" },
                  ].map((fmt) => (
                    <span key={fmt.label} className="inline-flex items-center gap-1 px-2 py-1 bg-gray-50 rounded text-xs text-gray-600">
                      <i className={`${fmt.icon} ${fmt.color} text-xs`}></i>
                      {fmt.label}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-lg border border-gray-100 p-6">
                <h2 className="font-semibold text-gray-900 mb-4">
                  Description <span className="text-gray-400 font-normal text-sm">(optional)</span>
                </h2>
                <textarea
                  name="description"
                  value={form.description}
                  onChange={handleChange}
                  placeholder="Briefly describe what this file covers, which chapters, topics, or exam it helps with..."
                  rows={4}
                  maxLength={500}
                  className="w-full px-4 py-3 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent resize-none transition-all"
                />
                <p className="text-xs text-gray-400 mt-1 text-right">{(form.description || "").length}/500</p>
              </div>
            </div>

            <div className="flex flex-col gap-6">
              <div className="bg-white rounded-lg border border-gray-100 p-6">
                <h2 className="font-semibold text-gray-900 mb-4">File Metadata</h2>
                <div className="flex flex-col gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Course Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="courseName"
                      value={form.courseName}
                      onChange={handleChange}
                      placeholder="e.g. Engineering Thermodynamics"
                      className={`w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all ${
                        errors.courseName ? "border-red-300" : "border-gray-200"
                      }`}
                    />
                    {errors.courseName && <p className="text-xs text-red-500 mt-1">{errors.courseName}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Instructor <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="instructor"
                      value={form.instructor}
                      onChange={handleChange}
                      placeholder="e.g. Dr. Khalid Hassan"
                      className={`w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all ${
                        errors.instructor ? "border-red-300" : "border-gray-200"
                      }`}
                    />
                    {errors.instructor && <p className="text-xs text-red-500 mt-1">{errors.instructor}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      College <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="college"
                      value={form.college}
                      onChange={handleChange}
                      placeholder="e.g. Faculty of Engineering"
                      list="colleges-list"
                      className={`w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all ${
                        errors.college ? "border-red-300" : "border-gray-200"
                      }`}
                    />
                    <datalist id="colleges-list">
                      {COLLEGES.map((c) => (
                        <option key={c} value={c} />
                      ))}
                    </datalist>
                    {errors.college && <p className="text-xs text-red-500 mt-1">{errors.college}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Academic Year <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="year"
                      value={form.year}
                      onChange={handleChange}
                      placeholder="e.g. 2025"
                      list="years-list"
                      className={`w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all ${
                        errors.year ? "border-red-300" : "border-gray-200"
                      }`}
                    />
                    <datalist id="years-list">
                      {YEARS.map((y) => (
                        <option key={y} value={String(y)} />
                      ))}
                    </datalist>
                    {errors.year && <p className="text-xs text-red-500 mt-1">{errors.year}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Academic Level <span className="text-red-500">*</span>
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                      {LEVELS.map((l) => {
                        const num = parseInt(l, 10);
                        return (
                          <button
                            key={l}
                            type="button"
                            onClick={() => {
                              setForm((prev) => ({ ...prev, level: String(num) }));
                              setErrors((prev) => ({ ...prev, level: undefined }));
                            }}
                            className={`px-2.5 py-1 rounded-full text-xs transition-colors cursor-pointer whitespace-nowrap ${
                              form.level === String(num)
                                ? "bg-sky-500 text-white"
                                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                            }`}
                          >
                            {l}
                          </button>
                        );
                      })}
                    </div>
                    {errors.level && <p className="text-xs text-red-500 mt-1">{errors.level}</p>}
                  </div>
                </div>
              </div>

              <div className="bg-sky-50 rounded-lg border border-sky-100 p-4">
                <h3 className="text-sm font-semibold text-sky-800 mb-2 flex items-center gap-1.5">
                  <div className="w-4 h-4 flex items-center justify-center">
                    <i className="ri-information-line text-sky-500 text-sm"></i>
                  </div>
                  Upload Guidelines
                </h3>
                <ul className="flex flex-col gap-1.5">
                  {[
                    "Files are reviewed by admins before publishing",
                    "Only upload your own notes or materials you have rights to share",
                    "Ensure content is relevant and accurate",
                    "Max file size: 50MB",
                  ].map((tip) => (
                    <li key={tip} className="flex items-start gap-1.5 text-xs text-sky-700">
                      <div className="w-3 h-3 flex items-center justify-center mt-0.5 flex-shrink-0">
                        <i className="ri-check-line text-sky-500 text-xs"></i>
                      </div>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 bg-sky-500 hover:bg-sky-600 disabled:opacity-60 text-white text-sm font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap"
              >
                {submitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <i className="ri-loader-4-line animate-spin text-sm"></i>
                    Uploading...
                  </span>
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    <i className="ri-upload-cloud-2-line text-sm"></i>
                    Submit for Review
                  </span>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}