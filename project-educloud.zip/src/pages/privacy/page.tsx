import Navbar from "@/components/feature/Navbar";

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <main className="max-w-3xl mx-auto px-4 md:px-6 py-10 md:py-16">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Privacy Policy</h1>
          <p className="text-sm text-gray-500">Last updated: May 2026</p>
        </div>

        <div className="prose prose-sm max-w-none text-gray-700 leading-relaxed space-y-6">
          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">1. Information We Collect</h2>
            <p>
              We collect your name, university email, college, and uploaded academic materials. We also collect anonymized usage data to improve the platform.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">2. Communication & Notifications</h2>
            <p>
              We use your email for platform notifications only: upload status updates, moderation actions, security alerts, password resets, and policy changes. We do not send promotional emails unless you opt in, and we never share your email with advertisers.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">3. How We Use Your Data</h2>
            <ul className="list-disc pl-5 space-y-1.5">
              <li>To operate and maintain the platform.</li>
              <li>To review and approve uploaded content.</li>
              <li>To recommend materials relevant to your college.</li>
              <li>To analyze usage trends and improve the service.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">4. Data Storage & Security</h2>
            <p>
              Passwords are hashed and never stored in plain text. Files are stored securely with access controls. We encrypt data in transit and restrict internal access to authorized personnel only.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">5. Sharing & Disclosure</h2>
            <p>
              We do not sell or trade your personal information. Data is only shared with hosting providers under confidentiality agreements, or when required by law.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">6. Your Rights</h2>
            <p>
              You can access and update your profile at any time. You may request deletion of your account and all associated data through your profile settings.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">7. Cookies</h2>
            <p>
              We use essential cookies for session and authentication. We do not use third-party advertising cookies. Disabling cookies may affect some features.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">8. Changes to This Policy</h2>
            <p>
              We may update this policy from time to time. Significant changes will be posted on the platform. Continued use constitutes acceptance of the revised policy.
            </p>
          </section>
        </div>
      </main>

      <footer className="border-t border-gray-100 py-6">
        <div className="max-w-3xl mx-auto px-4 md:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-gray-400">&copy; 2026 EduCloud. All rights reserved.</p>
          <p className="text-xs text-gray-400">Qassim University student project.</p>
        </div>
      </footer>
    </div>
  );
}