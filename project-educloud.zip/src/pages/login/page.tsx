import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email || !password) {
      setError("Please fill in all fields.");
      return;
    }
    setLoading(true);
    const { error: signInError, role } = await signIn(email, password);
    if (signInError) {
      setLoading(false);
      setError(signInError);
      return;
    }

    setLoading(false);
    if (role === "admin") {
      navigate("/admin");
    } else {
      navigate("/");
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Panel */}
      <div
        className="hidden lg:flex lg:w-1/2 relative flex-col justify-between p-12"
        style={{ background: "linear-gradient(135deg, #0c4a6e 0%, #0369a1 40%, #0ea5e9 100%)" }}
      >
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "url('https://readdy.ai/api/search-image?query=abstract%20geometric%20pattern%20with%20soft%20glowing%20lines%20and%20dots%20on%20deep%20blue%20background%20academic%20knowledge%20network%20minimal%20elegant%20design%20with%20subtle%20grid%20overlay&width=800&height=1200&seq=login-bg-sky-01&orientation=portrait')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            opacity: 0.15,
          }}
        />
        <div className="relative z-10">
          <img
            src="https://public.readdy.ai/ai/img_res/3ba78bc6-c77d-4826-b730-dd7df7129ad4.png"
            alt="StudyHub"
            className="h-12 w-auto object-contain brightness-0 invert"
          />
        </div>
        <div className="relative z-10">
          <h2 className="text-3xl font-bold text-white leading-tight mb-4">
            Your academic knowledge,<br />all in one place.
          </h2>
          <p className="text-sky-200 text-base leading-relaxed mb-8">
            Access thousands of lectures, summaries, and revision files shared by students across your university.
          </p>
          <div className="flex flex-col gap-4">
            {[
              { icon: "ri-file-text-line", text: "Browse approved academic materials" },
              { icon: "ri-search-line", text: "Search by course, instructor, or college" },
              { icon: "ri-star-line", text: "Rate and review content quality" },
            ].map((item) => (
              <div key={item.text} className="flex items-center gap-3">
                <div className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10">
                  <i className={`${item.icon} text-sky-300 text-sm`}></i>
                </div>
                <span className="text-sky-100 text-sm">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div className="flex-1 flex items-center justify-center px-6 py-12 bg-white">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex justify-center mb-8">
            <img
              src="https://public.readdy.ai/ai/img_res/3ba78bc6-c77d-4826-b730-dd7df7129ad4.png"
              alt="StudyHub"
              className="h-10 w-auto object-contain"
            />
          </div>

          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-900 mb-1">Welcome back</h1>
            <p className="text-gray-500 text-sm">Sign in to your account to continue</p>
          </div>

          {error && (
            <div className="mb-4 px-4 py-3 rounded-lg bg-red-50 border border-red-100 flex items-start gap-2">
              <i className="ri-error-warning-line text-red-500 text-sm mt-0.5"></i>
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Email address
              </label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                  <i className="ri-mail-line text-gray-400 text-sm"></i>
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@university.edu"
                  className="w-full pl-9 pr-4 py-2.5 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-sm font-medium text-gray-700">Password</label>
                <a href="#" className="text-xs text-sky-500 hover:text-sky-600 cursor-pointer">
                  Forgot password?
                </a>
              </div>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                  <i className="ri-lock-line text-gray-400 text-sm"></i>
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-9 pr-10 py-2.5 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <i className={`text-sm ${showPassword ? "ri-eye-off-line" : "ri-eye-line"}`}></i>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="remember"
                className="w-4 h-4 rounded border-gray-300 text-sky-500 focus:ring-sky-400 cursor-pointer"
              />
              <label htmlFor="remember" className="text-sm text-gray-600 cursor-pointer">
                Remember me for 30 days
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 text-sm font-semibold text-white bg-sky-500 hover:bg-sky-600 disabled:opacity-60 rounded-md transition-colors cursor-pointer whitespace-nowrap mt-1"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <i className="ri-loader-4-line animate-spin text-sm"></i>
                  Signing in...
                </span>
              ) : (
                "Sign In"
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500">
              Don&apos;t have an account?{" "}
              <Link to="/register" className="text-sky-500 font-medium hover:text-sky-600 cursor-pointer">
                Create one
              </Link>
            </p>
          </div>

          <div className="mt-8 pt-6 border-t border-gray-100 text-center">
            <p className="text-xs text-gray-400">
              By signing in, you agree to our{" "}
              <Link to="/terms" className="text-gray-500 hover:text-gray-700 cursor-pointer">Terms of Service</Link>
              {" "}and{" "}
              <Link to="/privacy" className="text-gray-500 hover:text-gray-700 cursor-pointer">Privacy Policy</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
