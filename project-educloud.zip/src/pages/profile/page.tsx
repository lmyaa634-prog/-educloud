import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "@/components/feature/Navbar";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";

const FILE_TYPE_CONFIG: Record<string, { icon: string; color: string; bg: string }> = {
  pdf: { icon: "ri-file-pdf-line", color: "text-red-600", bg: "bg-red-50" },
  ppt: { icon: "ri-file-ppt-line", color: "text-orange-600", bg: "bg-orange-50" },
  docx: { icon: "ri-file-word-line", color: "text-sky-600", bg: "bg-sky-50" },
  image: { icon: "ri-image-line", color: "text-violet-600", bg: "bg-violet-50" },
  video: { icon: "ri-video-line", color: "text-pink-600", bg: "bg-pink-50" },
};

interface FileRecord {
  id: number;
  title: string;
  file_type: string;
  course_name: string;
  college: string;
  level: number;
  status: string;
  stars_avg: number;
  views: number;
  created_at: string;
}

interface ActivityItem {
  type: string;
  text: string;
  date: string;
  icon: string;
  color: string;
  bg: string;
}

type Tab = "uploads" | "favorites" | "history";

export default function ProfilePage() {
  const { user, loading: authLoading, refreshUser } = useAuth();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<Tab>("uploads");
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editForm, setEditForm] = useState({
    full_name: "",
    email: "",
    college: "",
    level: "",
    bio: "",
  });

  const [userFiles, setUserFiles] = useState<FileRecord[]>([]);
  const [userFavorites, setUserFavorites] = useState<FileRecord[]>([]);
  const [activityItems, setActivityItems] = useState<ActivityItem[]>([]);
  const [stats, setStats] = useState({ uploads: 0, downloads: 0, favorites: 0, avgRating: 0 });
  const [dataLoading, setDataLoading] = useState(true);
  const [deleteFileId, setDeleteFileId] = useState<number | null>(null);
  const [deleteProcessing, setDeleteProcessing] = useState(false);

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user]);

  const loadData = async () => {
    setDataLoading(true);

    /* ---------- user's uploads ---------- */
    const { data: filesData } = await supabase
      .from("files")
      .select("id, title, file_type, course_name, college, level, status, stars_avg, views, created_at")
      .eq("uploader_id", user!.id)
      .order("created_at", { ascending: false });

    const uploads = filesData || [];
    setUserFiles(uploads);

    const totalDownloads = uploads.reduce((s, f) => s + (f.views || 0), 0);
    const avgRating = uploads.length > 0
      ? uploads.reduce((s, f) => s + (f.stars_avg || 0), 0) / uploads.length
      : 0;

    /* ---------- user's favorites ---------- */
    const { data: favRows } = await supabase
      .from("favorites")
      .select("file_id, created_at")
      .eq("user_id", user!.id);

    const favFileIds = (favRows || []).map((r) => r.file_id);
    let favFiles: FileRecord[] = [];
    if (favFileIds.length > 0) {
      const { data: favFilesData } = await supabase
        .from("files")
        .select("id, title, file_type, course_name, college, level, status, stars_avg, views, created_at")
        .in("id", favFileIds);
      favFiles = favFilesData || [];
    }
    setUserFavorites(favFiles);

    setStats({
      uploads: uploads.length,
      downloads: totalDownloads,
      favorites: favRows?.length || 0,
      avgRating: Number(avgRating.toFixed(1)),
    });

    /* ---------- activity history ---------- */
    const activity: ActivityItem[] = [];

    uploads.forEach((f) =>
      activity.push({
        type: "upload",
        text: `Uploaded "${f.title}"`,
        date: f.created_at,
        icon: "ri-upload-cloud-line",
        color: "text-sky-500",
        bg: "bg-sky-50",
      })
    );

    const { data: commentsRaw } = await supabase
      .from("comments")
      .select("file_id, comment_text, created_at")
      .eq("user_id", user!.id)
      .order("created_at", { ascending: false })
      .limit(20);

    const commentFileIds = [...new Set((commentsRaw || []).map((c) => c.file_id))];
    if (commentFileIds.length > 0) {
      const { data: commentFiles } = await supabase
        .from("files")
        .select("id, title")
        .in("id", commentFileIds);
      const titleMap = new Map((commentFiles || []).map((f) => [f.id, f.title]));
      (commentsRaw || []).forEach((c) =>
        activity.push({
          type: "comment",
          text: `Commented on "${titleMap.get(c.file_id) || "a file"}"`,
          date: c.created_at,
          icon: "ri-chat-3-line",
          color: "text-sky-600",
          bg: "bg-sky-50",
        })
      );
    }

    const { data: ratingsRaw } = await supabase
      .from("ratings")
      .select("file_id, rating, created_at")
      .eq("user_id", user!.id)
      .order("created_at", { ascending: false })
      .limit(20);

    const ratingFileIds = [...new Set((ratingsRaw || []).map((r) => r.file_id))];
    if (ratingFileIds.length > 0) {
      const { data: ratingFiles } = await supabase
        .from("files")
        .select("id, title")
        .in("id", ratingFileIds);
      const titleMap = new Map((ratingFiles || []).map((f) => [f.id, f.title]));
      (ratingsRaw || []).forEach((r) =>
        activity.push({
          type: "rating",
          text: `Rated "${titleMap.get(r.file_id) || "a file"}" ${r.rating} stars`,
          date: r.created_at,
          icon: "ri-star-line",
          color: "text-amber-600",
          bg: "bg-amber-50",
        })
      );
    }

    const favMap = new Map((favRows || []).map((r) => [r.file_id, r.created_at]));
    favFiles.forEach((f) =>
      activity.push({
        type: "favorite",
        text: `Saved "${f.title}"`,
        date: favMap.get(f.id) || f.created_at,
        icon: "ri-bookmark-line",
        color: "text-amber-600",
        bg: "bg-amber-50",
      })
    );

    activity.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    setActivityItems(activity.slice(0, 20));

    setDataLoading(false);
  };

  const handleDelete = async (id: number) => {
    setDeleteProcessing(true);
    // Also remove from storage
    const { data: fileData } = await supabase.from("files").select("file_url").eq("id", id).maybeSingle();
    if (fileData?.file_url) {
      await supabase.storage.from("file_storage").remove([fileData.file_url]);
    }
    await supabase.from("files").delete().eq("id", id);
    setDeleteFileId(null);
    setDeleteProcessing(false);
    await loadData();
  };

  const openEdit = () => {
    if (!user) return;
    setEditForm({
      full_name: user.full_name || "",
      email: user.email || "",
      college: user.college || "",
      level: user.level || "",
      bio: user.bio || "",
    });
    setIsEditOpen(true);
  };

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: editForm.full_name,
        college: editForm.college,
        level: editForm.level,
        bio: editForm.bio,
      })
      .eq("id", user.id);
    setSaving(false);
    if (!error) {
      await refreshUser();
      setIsEditOpen(false);
    }
  };

  const joinedAt = useMemo(() => {
    if (!user?.created_at) return "Recently";
    return new Date(user.created_at).toLocaleDateString("en-US", { month: "long", year: "numeric" });
  }, [user?.created_at]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-10 h-10 flex items-center justify-center">
          <i className="ri-loader-4-line animate-spin text-sky-500 text-2xl"></i>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 flex items-center justify-center mx-auto mb-3">
            <i className="ri-user-line text-gray-300 text-4xl"></i>
          </div>
          <h2 className="text-lg font-semibold text-gray-900 mb-1">You are not signed in</h2>
          <p className="text-sm text-gray-500 mb-4">Sign in to view your profile and manage your uploads.</p>
          <button
            onClick={() => navigate("/login")}
            className="px-5 py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const displayName = user.full_name || "Student";
  const displayCollege = user.college || "No college set";
  const displayLevel = user.level || "No level set";
  const displayBio = user.bio || "No bio yet. Click Edit Profile to add one!";
  const displayAvatar = user.avatar || null;

  const tabs: { id: Tab; label: string; icon: string; count: number }[] = [
    { id: "uploads", label: "My Uploads", icon: "ri-upload-cloud-line", count: stats.uploads },
    { id: "favorites", label: "Favorites", icon: "ri-bookmark-line", count: stats.favorites },
    { id: "history", label: "Activity", icon: "ri-history-line", count: activityItems.length },
  ];

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    } catch {
      return iso;
    }
  };

  const renderFileList = (files: FileRecord[], showDelete = false) => {
    if (files.length === 0) {
      return (
        <div className="bg-white rounded-lg border border-gray-100 p-8 text-center">
          <div className="w-12 h-12 flex items-center justify-center mx-auto mb-3">
            <i className="ri-folder-open-line text-gray-300 text-3xl"></i>
          </div>
          <p className="text-sm text-gray-500">Nothing here yet.</p>
        </div>
      );
    }
    return (
      <div className="flex flex-col gap-3">
        {files.map((file) => {
          const typeConfig = FILE_TYPE_CONFIG[file.file_type] || FILE_TYPE_CONFIG.pdf;
          return (
            <div
              key={file.id}
              className="group flex items-start gap-4 bg-white rounded-lg border border-gray-100 hover:border-sky-200 p-4 transition-all"
            >
              <Link
                to={`/file/${file.id}`}
                className="flex items-start gap-4 flex-1 min-w-0 cursor-pointer"
              >
                <div className={`w-10 h-10 flex items-center justify-center rounded-lg flex-shrink-0 ${typeConfig.bg}`}>
                  <i className={`${typeConfig.icon} ${typeConfig.color} text-lg`}></i>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-gray-900 group-hover:text-sky-600 transition-colors line-clamp-1">
                    {file.title}
                  </h4>
                  <div className="flex flex-wrap items-center gap-2 mt-1">
                    <span className="text-xs text-gray-500">{file.course_name}</span>
                    <span className="text-gray-300">&middot;</span>
                    <span className="text-xs text-gray-500">
                      {file.college?.replace("Faculty of ", "") || "General"}
                    </span>
                    <span className="text-gray-300">&middot;</span>
                    <span className="text-xs text-gray-500">Year {file.level}</span>
                  </div>
                  <div className="flex items-center gap-3 mt-2">
                    <div className="flex items-center gap-0.5">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <div key={s} className="w-3 h-3 flex items-center justify-center">
                          <i
                            className={`${
                              s <= Math.round(file.stars_avg || 0) ? "ri-star-fill" : "ri-star-line"
                            } text-amber-400 text-xs`}
                          ></i>
                        </div>
                      ))}
                      <span className="text-xs text-gray-600 ml-1">{file.stars_avg?.toFixed(1) || "0.0"}</span>
                    </div>
                    <span className="text-xs text-gray-400 flex items-center gap-1">
                      <i className="ri-download-line text-xs"></i>
                      {(file.views || 0).toLocaleString()}
                    </span>
                    <span
                      className={`ml-auto text-xs px-2 py-0.5 rounded-full ${
                        file.status === "approved" ? "bg-sky-50 text-sky-700" : "bg-amber-50 text-amber-700"
                      }`}
                    >
                      {file.status === "approved" ? "Approved" : "Pending"}
                    </span>
                  </div>
                </div>
              </Link>
              {showDelete && (
                <button
                  onClick={() => setDeleteFileId(file.id)}
                  className="flex-shrink-0 w-7 h-7 flex items-center justify-center text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors cursor-pointer mt-1"
                  title="Delete file"
                >
                  <i className="ri-delete-bin-line text-sm"></i>
                </button>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Edit Profile Modal */}
      {isEditOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
          <div className="bg-white rounded-xl w-full max-w-md shadow-lg overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">Edit Profile</h2>
              <button
                onClick={() => setIsEditOpen(false)}
                className="w-8 h-8 flex items-center justify-center rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-lg"></i>
              </button>
            </div>
            <div className="px-6 py-5 flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <img
                  src={displayAvatar || undefined}
                  alt={displayName}
                  className="w-14 h-14 rounded-full object-cover object-top border-2 border-gray-200"
                />
                <div>
                  <p className="text-sm font-medium text-gray-700">Profile Photo</p>
                  <p className="text-xs text-gray-400 mt-0.5">Photo is set automatically</p>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Full Name</label>
                <input
                  type="text"
                  value={editForm.full_name}
                  onChange={(e) => setEditForm((f) => ({ ...f, full_name: e.target.value }))}
                  className="w-full border border-gray-200 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-sky-400 transition-colors"
                  placeholder="Your full name"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Email Address</label>
                <input
                  type="email"
                  value={editForm.email}
                  readOnly
                  className="w-full border border-gray-200 rounded-md px-3 py-2 text-sm text-gray-400 bg-gray-50 cursor-not-allowed"
                  placeholder="your@email.com"
                />
                <p className="text-xs text-gray-400 mt-0.5">Email cannot be changed</p>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">College / Faculty</label>
                <input
                  type="text"
                  value={editForm.college}
                  onChange={(e) => setEditForm((f) => ({ ...f, college: e.target.value }))}
                  className="w-full border border-gray-200 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-sky-400 transition-colors"
                  placeholder="e.g. Faculty of Engineering"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Academic Level</label>
                <input
                  type="text"
                  value={editForm.level}
                  onChange={(e) => setEditForm((f) => ({ ...f, level: e.target.value }))}
                  className="w-full border border-gray-200 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-sky-400 transition-colors"
                  placeholder="e.g. 3rd Year"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Bio</label>
                <textarea
                  value={editForm.bio}
                  onChange={(e) => setEditForm((f) => ({ ...f, bio: e.target.value }))}
                  rows={3}
                  maxLength={300}
                  className="w-full border border-gray-200 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-sky-400 transition-colors resize-none"
                  placeholder="Tell others a bit about yourself..."
                />
                <p className="text-xs text-gray-400 text-right mt-0.5">{editForm.bio.length}/300</p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-gray-100 bg-gray-50">
              <button
                onClick={() => setIsEditOpen(false)}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 rounded-md hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="px-5 py-2 bg-sky-500 hover:bg-sky-600 disabled:opacity-60 text-white text-sm font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
              >
                {saving ? (
                  <span className="flex items-center gap-1.5">
                    <i className="ri-loader-4-line animate-spin text-xs"></i>
                    Saving...
                  </span>
                ) : (
                  "Save Changes"
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm Modal */}
      {deleteFileId !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
          <div className="bg-white rounded-lg w-full max-w-sm p-6 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 flex items-center justify-center bg-red-50 rounded-full">
                <i className="ri-delete-bin-line text-red-500 text-xl"></i>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900">Delete File</h4>
                <p className="text-xs text-gray-500">This action cannot be undone</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-5">
              Are you sure you want to permanently delete this file? It will be removed from the platform and storage immediately.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setDeleteFileId(null)}
                className="flex-1 py-2 border border-gray-200 text-gray-700 text-sm rounded-md hover:bg-gray-50 cursor-pointer whitespace-nowrap transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteFileId)}
                disabled={deleteProcessing}
                className="flex-1 py-2 bg-red-500 hover:bg-red-600 disabled:opacity-60 text-white text-sm font-medium rounded-md cursor-pointer whitespace-nowrap transition-colors"
              >
                {deleteProcessing ? (
                  <span className="flex items-center justify-center gap-1">
                    <i className="ri-loader-4-line animate-spin text-xs"></i>
                    Deleting...
                  </span>
                ) : (
                  "Delete"
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Profile Header */}
      <div className="bg-sky-700 pt-10 pb-0">
        <div className="max-w-5xl mx-auto px-4 md:px-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-end gap-5 pb-6">
            <div className="relative">
              {displayAvatar ? (
                <img
                  src={displayAvatar}
                  alt={displayName}
                  className="w-20 h-20 rounded-full object-cover object-top border-4 border-white"
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-gray-200 border-4 border-white flex items-center justify-center">
                  <span className="text-2xl font-bold text-gray-500">
                    {displayName.charAt(0).toUpperCase()}
                  </span>
                </div>
              )}
              <div className="absolute bottom-0 right-0 w-6 h-6 flex items-center justify-center bg-sky-500 rounded-full border-2 border-white">
                <i className="ri-graduation-cap-line text-white text-xs"></i>
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-xl font-bold text-white">{displayName}</h1>
                <span className="px-2.5 py-0.5 bg-white/20 text-white text-xs rounded-full capitalize">
                  {user.role}
                </span>
              </div>
              <p className="text-sky-200 text-sm mt-0.5">{user.email}</p>
              <div className="flex flex-wrap items-center gap-3 mt-2">
                <span className="flex items-center gap-1 text-sky-200 text-xs">
                  <i className="ri-building-line text-xs"></i>
                  {displayCollege}
                </span>
                <span className="flex items-center gap-1 text-sky-200 text-xs">
                  <i className="ri-graduation-cap-line text-xs"></i>
                  {displayLevel}
                </span>
                <span className="flex items-center gap-1 text-sky-200 text-xs">
                  <i className="ri-calendar-line text-xs"></i>
                  Joined {joinedAt}
                </span>
              </div>
            </div>
            <button
              onClick={openEdit}
              className="flex items-center gap-1.5 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-sm rounded-md transition-colors cursor-pointer whitespace-nowrap border border-white/20"
            >
              <i className="ri-edit-line text-sm"></i>
              Edit Profile
            </button>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-4 border-t border-sky-600">
            {[
              { label: "Uploads", value: stats.uploads.toString(), icon: "ri-upload-cloud-line" },
              { label: "Downloads", value: stats.downloads >= 1000 ? `${(stats.downloads / 1000).toFixed(1)}k` : stats.downloads.toString(), icon: "ri-download-line" },
              { label: "Favorites", value: stats.favorites.toString(), icon: "ri-bookmark-line" },
              { label: "Avg. Rating", value: stats.avgRating.toFixed(1), icon: "ri-star-line" },
            ].map((stat) => (
              <div
                key={stat.label}
                className="flex flex-col items-center py-4 border-r border-sky-600 last:border-0"
              >
                <p className="text-white font-bold text-lg">{stat.value}</p>
                <p className="text-sky-300 text-xs">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 md:px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Main Content */}
          <div className="flex-1 min-w-0">
            {/* Tabs */}
            <div className="flex items-center gap-1 bg-gray-100 rounded-full px-1 py-1 mb-6 w-fit">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    activeTab === tab.id ? "bg-white text-gray-900" : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <i className={`${tab.icon} text-xs`}></i>
                  {tab.label}
                  <span
                    className={`text-xs px-1.5 py-0.5 rounded-full ${
                      activeTab === tab.id ? "bg-sky-100 text-sky-700" : "bg-gray-200 text-gray-500"
                    }`}
                  >
                    {tab.count}
                  </span>
                </button>
              ))}
            </div>

            {dataLoading ? (
              <div className="flex items-center justify-center py-16">
                <i className="ri-loader-4-line animate-spin text-sky-500 text-2xl"></i>
              </div>
            ) : (
              <>
                {activeTab === "uploads" && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="font-semibold text-gray-900">My Uploaded Files</h2>
                      <Link
                        to="/upload"
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-500 hover:bg-sky-600 text-white text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-add-line text-xs"></i>
                        Upload New
                      </Link>
                    </div>
                    {renderFileList(userFiles, true)}
                  </div>
                )}

                {activeTab === "favorites" && (
                  <div>
                    <h2 className="font-semibold text-gray-900 mb-4">Saved Files</h2>
                    {renderFileList(userFavorites)}
                  </div>
                )}

                {activeTab === "history" && (
                  <div>
                    <h2 className="font-semibold text-gray-900 mb-4">Activity History</h2>
                    {activityItems.length === 0 ? (
                      <div className="bg-white rounded-lg border border-gray-100 p-8 text-center">
                        <div className="w-12 h-12 flex items-center justify-center mx-auto mb-3">
                          <i className="ri-history-line text-gray-300 text-3xl"></i>
                        </div>
                        <p className="text-sm text-gray-500">No activity yet.</p>
                      </div>
                    ) : (
                      <div className="bg-white rounded-lg border border-gray-100 divide-y divide-gray-50">
                        {activityItems.map((item, i) => (
                          <div key={i} className="flex items-start gap-3 p-4">
                            <div className={`w-8 h-8 flex items-center justify-center rounded-lg flex-shrink-0 ${item.bg}`}>
                              <i className={`${item.icon} ${item.color} text-sm`}></i>
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm text-gray-700">{item.text}</p>
                              <p className="text-xs text-gray-400 mt-0.5">{formatDate(item.date)}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>

          {/* Sidebar */}
          <aside className="w-full lg:w-64 flex-shrink-0">
            {/* Bio */}
            <div className="bg-white rounded-lg border border-gray-100 p-5 mb-4">
              <h3 className="font-semibold text-gray-900 text-sm mb-3">About</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{displayBio}</p>
            </div>

            {/* Contribution Badge */}
            {stats.uploads > 0 && (
              <div className="bg-sky-50 rounded-lg border border-sky-100 p-5 mb-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 flex items-center justify-center bg-sky-100 rounded-full">
                    <i className="ri-award-line text-sky-500 text-xl"></i>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-sky-800">Contributor</p>
                    <p className="text-xs text-sky-600">{user.college || "Your Faculty"}</p>
                  </div>
                </div>
                <p className="text-xs text-sky-700">
                  Your uploads have been downloaded <strong>{stats.downloads.toLocaleString()}</strong> times!
                </p>
              </div>
            )}

            {/* Quick Links */}
            <div className="bg-white rounded-lg border border-gray-100 p-5">
              <h3 className="font-semibold text-gray-900 text-sm mb-3">Quick Actions</h3>
              <div className="flex flex-col gap-2">
                {[
                  { label: "Upload a File", icon: "ri-upload-cloud-line", to: "/upload" },
                  { label: "Browse Materials", icon: "ri-search-line", to: "/search" },
                  { label: "View Home", icon: "ri-home-line", to: "/" },
                ].map((action) => (
                  <Link
                    key={action.label}
                    to={action.to}
                    className="flex items-center gap-2 px-3 py-2 rounded-md text-sm text-gray-600 hover:bg-gray-50 hover:text-sky-600 transition-colors cursor-pointer"
                  >
                    <div className="w-4 h-4 flex items-center justify-center">
                      <i className={`${action.icon} text-sm`}></i>
                    </div>
                    {action.label}
                  </Link>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}