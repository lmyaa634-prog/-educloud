import { useState, useEffect } from "react";
import { getStoragePublicUrl, getFileDownloadUrl } from "@/lib/helpers";

interface FileViewerProps {
  fileType: string;
  title: string;
  fileUrl?: string | null;
}

export default function FileViewer({ fileType, title, fileUrl }: FileViewerProps) {
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!fileUrl) {
      setLoading(false);
      return;
    }
    setLoading(true);
    getFileDownloadUrl(fileUrl).then((url) => {
      setDownloadUrl(url);
      setLoading(false);
    });
  }, [fileUrl]);

  const publicUrl = fileUrl ? getStoragePublicUrl(fileUrl) : null;

  if (loading) {
    return (
      <div className="w-full h-[500px] md:h-[600px] flex items-center justify-center bg-gray-50 rounded-lg">
        <div className="flex items-center gap-2 text-gray-400">
          <i className="ri-loader-4-line animate-spin text-xl"></i>
          <span className="text-sm">Loading preview...</span>
        </div>
      </div>
    );
  }

  if (!fileUrl || !publicUrl) {
    return (
      <div className="w-full h-[500px] md:h-[600px] flex items-center justify-center bg-gray-100 rounded-lg">
        <div className="text-center">
          <div className="w-16 h-16 flex items-center justify-center mx-auto mb-4 bg-gray-200 rounded-full">
            <i className="ri-file-line text-gray-400 text-3xl"></i>
          </div>
          <h3 className="font-semibold text-gray-700 mb-1">No preview available</h3>
          <p className="text-sm text-gray-400">This file cannot be previewed at the moment.</p>
        </div>
      </div>
    );
  }

  if (fileType === "pdf" && downloadUrl) {
    return (
      <div className="w-full h-[500px] md:h-[600px] bg-white rounded-lg border border-gray-100 overflow-hidden">
        <iframe
          src={downloadUrl}
          title={title}
          className="w-full h-full"
        />
      </div>
    );
  }

  if (fileType === "image" && downloadUrl) {
    return (
      <div className="w-full h-[500px] md:h-[600px] flex items-center justify-center bg-gray-50 rounded-lg p-4">
        <img
          src={downloadUrl}
          alt={title}
          className="max-w-full max-h-full object-contain rounded-lg"
        />
      </div>
    );
  }

  if (fileType === "video" && downloadUrl) {
    return (
      <div className="w-full h-[500px] md:h-[600px] flex items-center justify-center bg-black rounded-lg">
        <div className="w-full max-w-3xl mx-auto">
          <video controls className="w-full rounded-lg" poster="">
            <source src={downloadUrl} />
            Your browser does not support the video tag.
          </video>
        </div>
      </div>
    );
  }

  // Generic fallback for PPT, DOCX, or when download URL is not ready
  const typeConfig: Record<string, { icon: string; color: string; bg: string; label: string }> = {
    pdf: { icon: "ri-file-pdf-line", color: "text-red-500", bg: "bg-red-50", label: "PDF Document" },
    ppt: { icon: "ri-file-ppt-line", color: "text-orange-500", bg: "bg-orange-50", label: "PowerPoint" },
    docx: { icon: "ri-file-word-line", color: "text-sky-500", bg: "bg-sky-50", label: "Word Document" },
    image: { icon: "ri-image-line", color: "text-violet-500", bg: "bg-violet-50", label: "Image" },
    video: { icon: "ri-video-line", color: "text-pink-500", bg: "bg-pink-50", label: "Video" },
    other: { icon: "ri-file-line", color: "text-gray-500", bg: "bg-gray-50", label: "File" },
  };

  const cfg = typeConfig[fileType] || typeConfig.other;

  return (
    <div className="w-full h-[500px] md:h-[600px] flex flex-col items-center justify-center bg-gray-100 rounded-lg">
      <div className="w-16 h-16 flex items-center justify-center mx-auto mb-4 bg-white rounded-full border border-gray-200">
        <i className={`${cfg.icon} ${cfg.color} text-3xl`}></i>
      </div>
      <h3 className="font-semibold text-gray-800 mb-1">{title}</h3>
      <p className="text-sm text-gray-500 mb-6">{cfg.label}</p>
      {downloadUrl && (
        <a
          href={downloadUrl}
          download={title}
          className="px-5 py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap inline-flex items-center gap-2"
        >
          <i className="ri-download-line text-sm"></i>
          Download File
        </a>
      )}
    </div>
  );
}