import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";
import { formatDate } from "@/lib/helpers";

interface Comment {
  id: number;
  user_id: string;
  authorName: string;
  authorAvatar: string | null;
  content: string;
  createdAt: string;
}

interface CommentsSectionProps {
  fileId: string;
}

function CommentItem({ comment }: { comment: Comment }) {
  return (
    <div className="flex gap-3 py-4 border-b border-gray-50 last:border-0">
      {comment.authorAvatar ? (
        <img
          src={comment.authorAvatar}
          alt={comment.authorName}
          className="w-8 h-8 rounded-full object-cover object-top flex-shrink-0"
        />
      ) : (
        <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-xs font-semibold text-gray-500 flex-shrink-0">
          {comment.authorName.charAt(0).toUpperCase()}
        </div>
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-medium text-gray-900">{comment.authorName}</span>
          <span className="text-xs text-gray-400">{formatDate(comment.createdAt)}</span>
        </div>
        <p className="text-sm text-gray-700 leading-relaxed">{comment.content}</p>
      </div>
    </div>
  );
}

export default function CommentsSection({ fileId }: CommentsSectionProps) {
  const { user } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadComments();
  }, [fileId]);

  const loadComments = async () => {
    setLoading(true);
    const numericId = Number.parseInt(fileId, 10);
    if (Number.isNaN(numericId)) {
      setLoading(false);
      return;
    }

    const { data } = await supabase
      .from("comments")
      .select("*, profiles:user_id(full_name, avatar)")
      .eq("file_id", numericId)
      .order("created_at", { ascending: false });

    const mapped: Comment[] = (data || []).map((c: any) => ({
      id: c.id,
      user_id: c.user_id,
      authorName: c.profiles?.full_name ?? "Unknown",
      authorAvatar: c.profiles?.avatar ?? null,
      content: c.comment_text,
      createdAt: c.created_at,
    }));

    setComments(mapped);
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;

    setSubmitting(true);
    const numericId = Number.parseInt(fileId, 10);
    if (Number.isNaN(numericId)) {
      setSubmitting(false);
      return;
    }

    const { error } = await supabase.from("comments").insert({
      file_id: numericId,
      user_id: user.id,
      comment_text: newComment.trim(),
    });

    if (!error) {
      setNewComment("");
      await loadComments();
    }
    setSubmitting(false);
  };

  return (
    <div className="bg-white rounded-lg border border-gray-100 p-6">
      <h3 className="font-semibold text-gray-900 mb-1">
        Comments <span className="text-gray-400 font-normal text-sm">({comments.length})</span>
      </h3>
      <p className="text-xs text-gray-500 mb-5">Ask questions or share your thoughts about this material</p>

      {/* Add Comment */}
      {user ? (
        <form onSubmit={handleSubmit} className="mb-6">
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value.slice(0, 500))}
            placeholder="Write a comment or ask a question..."
            rows={3}
            className="w-full px-4 py-3 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent resize-none transition-all"
          />
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-gray-400">{newComment.length}/500</span>
            <button
              type="submit"
              disabled={!newComment.trim() || submitting}
              className="px-4 py-2 bg-sky-500 hover:bg-sky-600 disabled:opacity-50 text-white text-sm font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
            >
              {submitting ? (
                <span className="flex items-center gap-1.5">
                  <i className="ri-loader-4-line animate-spin text-xs"></i>
                  Posting...
                </span>
              ) : (
                "Post Comment"
              )}
            </button>
          </div>
        </form>
      ) : (
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <p className="text-sm text-gray-500">Sign in to leave a comment on this file.</p>
        </div>
      )}

      {/* Comments List */}
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <i className="ri-loader-4-line animate-spin text-sky-500 text-xl"></i>
        </div>
      ) : comments.length > 0 ? (
        <div>
          {comments.map((comment) => (
            <CommentItem key={comment.id} comment={comment} />
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <div className="w-10 h-10 flex items-center justify-center mx-auto mb-2 bg-gray-50 rounded-full">
            <i className="ri-chat-3-line text-gray-300 text-xl"></i>
          </div>
          <p className="text-gray-400 text-sm">No comments yet. Be the first!</p>
        </div>
      )}
    </div>
  );
}