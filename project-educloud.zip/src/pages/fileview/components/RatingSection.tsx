import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";

interface RatingSectionProps {
  fileId: number;
  rating: number;
  ratingCount: number;
  likes: number;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

export default function RatingSection({
  fileId,
  rating,
  ratingCount,
  likes,
  isFavorite,
  onToggleFavorite,
}: RatingSectionProps) {
  const { user } = useAuth();
  const [userRating, setUserRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(likes);
  const [submitted, setSubmitted] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [reportSubmitted, setReportSubmitted] = useState(false);
  const [ratingBars, setRatingBars] = useState<{ star: number; percent: number; count: number }[]>([]);

  useEffect(() => {
    loadUserRating();
    loadRatingDistribution();
    loadUserLike();
  }, [fileId, user]);

  const loadUserRating = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("ratings")
      .select("rating")
      .eq("file_id", fileId)
      .eq("user_id", user.id)
      .maybeSingle();
    if (data) {
      setUserRating(data.rating ?? 0);
      setSubmitted(true);
    }
  };

  const loadUserLike = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("favorites")
      .select("id")
      .eq("file_id", fileId)
      .eq("user_id", user.id)
      .maybeSingle();
    // Only affect the like visual state if it's a "like" vs "favorite" distinction
    // For now we skip since favorites handles save
  };

  const loadRatingDistribution = async () => {
    const { data } = await supabase
      .from("ratings")
      .select("rating")
      .eq("file_id", fileId);
    const counts: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    let total = 0;
    for (const r of data || []) {
      const star = r.rating ?? 0;
      if (star >= 1 && star <= 5) {
        counts[star]++;
        total++;
      }
    }
    const bars = [5, 4, 3, 2, 1].map((star) => ({
      star,
      count: counts[star],
      percent: total > 0 ? Math.round((counts[star] / total) * 100) : 0,
    }));
    setRatingBars(bars);
  };

  const handleRate = async (star: number) => {
    if (!user) return;
    setUserRating(star);
    setSubmitted(true);

    // Upsert rating
    const { data: existing } = await supabase
      .from("ratings")
      .select("id")
      .eq("file_id", fileId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (existing) {
      await supabase.from("ratings").update({ rating: star }).eq("id", existing.id);
    } else {
      await supabase.from("ratings").insert({ file_id: fileId, user_id: user.id, rating: star });
    }

    // Recalculate average
    const { data: allRatings } = await supabase
      .from("ratings")
      .select("rating")
      .eq("file_id", fileId);
    const all = (allRatings || []).map((r) => r.rating).filter((r) => typeof r === "number");
    const avg = all.length > 0 ? all.reduce((a, b) => a + b, 0) / all.length : 0;
    await supabase.from("files").update({ stars_avg: Math.round(avg * 100) / 100 }).eq("id", fileId);

    loadRatingDistribution();
  };

  const handleLike = async () => {
    if (!user) return;
    const newLiked = !liked;
    setLiked(newLiked);
    setLikeCount((prev) => (newLiked ? prev + 1 : Math.max(0, prev - 1)));

    const { data: fileData } = await supabase
      .from("files")
      .select("likes")
      .eq("id", fileId)
      .maybeSingle();
    const currentLikes = fileData?.likes ?? 0;
    const newLikes = Math.max(0, currentLikes + (newLiked ? 1 : -1));
    await supabase.from("files").update({ likes: newLikes }).eq("id", fileId);
  };

  const handleReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !reportReason) return;

    await supabase.from("reports").insert({
      file_id: fileId,
      reporter_id: user.id,
      reason: reportReason,
      status: "pending",
    });

    setReportSubmitted(true);
    setTimeout(() => {
      setShowReport(false);
      setReportSubmitted(false);
      setReportReason("");
    }, 2000);
  };

  const effectiveRating = Number.isFinite(rating) && rating > 0 ? rating : 0;

  return (
    <div className="bg-white rounded-lg border border-gray-100 p-6">
      <h3 className="font-semibold text-gray-900 mb-5">Ratings &amp; Actions</h3>

      {/* Overall Rating */}
      <div className="flex items-start gap-6 mb-6 pb-6 border-b border-gray-100">
        <div className="text-center">
          <p className="text-5xl font-bold text-gray-900">
            {Number.isFinite(effectiveRating) ? effectiveRating.toFixed(1) : "0.0"}
          </p>
          <div className="flex items-center justify-center gap-0.5 my-1">
            {[1, 2, 3, 4, 5].map((s) => (
              <div key={s} className="w-4 h-4 flex items-center justify-center">
                <i
                  className={`${
                    s <= Math.round(effectiveRating) ? "ri-star-fill" : "ri-star-line"
                  } text-amber-400 text-sm`}
                ></i>
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-400">{ratingCount} ratings</p>
        </div>
        <div className="flex-1">
          {ratingBars.map(({ star, percent, count }) => (
            <div key={star} className="flex items-center gap-2 mb-1">
              <span className="text-xs text-gray-500 w-3">{star}</span>
              <div className="w-3 h-3 flex items-center justify-center">
                <i className="ri-star-fill text-amber-400 text-xs"></i>
              </div>
              <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-amber-400 rounded-full" style={{ width: `${percent}%` }}></div>
              </div>
              <span className="text-xs text-gray-400 w-8 text-right">{count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Rate This File */}
      <div className="mb-5">
        <p className="text-sm font-medium text-gray-700 mb-2">Rate this file</p>
        {!user ? (
          <p className="text-xs text-gray-400">Sign in to rate this file.</p>
        ) : submitted ? (
          <div className="flex items-center gap-2 text-sm text-sky-500">
            <div className="w-5 h-5 flex items-center justify-center">
              <i className="ri-checkbox-circle-fill text-sky-500"></i>
            </div>
            Thanks for rating! You gave {userRating} star{userRating !== 1 ? "s" : ""}.
          </div>
        ) : (
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                onClick={() => handleRate(star)}
                className="w-8 h-8 flex items-center justify-center cursor-pointer transition-transform hover:scale-110"
              >
                <i
                  className={`${
                    star <= (hoverRating || userRating)
                      ? "ri-star-fill text-amber-400"
                      : "ri-star-line text-gray-300"
                  } text-xl`}
                ></i>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={handleLike}
          disabled={!user}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
            liked
              ? "bg-red-50 text-red-600 border border-red-200"
              : "bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100"
          } disabled:opacity-50`}
        >
          <div className="w-4 h-4 flex items-center justify-center">
            <i className={`${liked ? "ri-heart-fill" : "ri-heart-line"} text-sm`}></i>
          </div>
          {liked ? "Liked" : "Like"} ({likeCount})
        </button>

        <button
          onClick={onToggleFavorite}
          disabled={!user}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
            isFavorite
              ? "bg-sky-50 text-sky-700 border border-sky-200"
              : "bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100"
          } disabled:opacity-50`}
        >
          <div className="w-4 h-4 flex items-center justify-center">
            <i className={`${isFavorite ? "ri-bookmark-fill" : "ri-bookmark-line"} text-sm`}></i>
          </div>
          {isFavorite ? "Saved" : "Save to Favorites"}
        </button>

        <button
          onClick={() => setShowReport(true)}
          disabled={!user}
          className="flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50"
        >
          <div className="w-4 h-4 flex items-center justify-center">
            <i className="ri-flag-line text-sm"></i>
          </div>
          Report
        </button>
      </div>

      {/* Report Modal */}
      {showReport && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-gray-900">Report Content</h4>
              <button
                onClick={() => setShowReport(false)}
                className="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-gray-600 cursor-pointer"
              >
                <i className="ri-close-line text-lg"></i>
              </button>
            </div>
            {reportSubmitted ? (
              <div className="text-center py-4">
                <div className="w-12 h-12 flex items-center justify-center mx-auto mb-3 bg-sky-50 rounded-full">
                  <i className="ri-checkbox-circle-line text-sky-500 text-2xl"></i>
                </div>
                <p className="text-gray-700 font-medium">Report submitted</p>
                <p className="text-gray-500 text-sm mt-1">Our team will review this content.</p>
              </div>
            ) : (
              <form onSubmit={handleReport}>
                <p className="text-sm text-gray-600 mb-4">Why are you reporting this file?</p>
                <div className="flex flex-col gap-2 mb-4">
                  {[
                    "Incorrect or misleading information",
                    "Copyright violation",
                    "Inappropriate content",
                    "Poor quality / spam",
                    "Other",
                  ].map((reason) => (
                    <label key={reason} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="reason"
                        value={reason}
                        checked={reportReason === reason}
                        onChange={() => setReportReason(reason)}
                        className="text-sky-500 focus:ring-sky-400"
                      />
                      <span className="text-sm text-gray-700">{reason}</span>
                    </label>
                  ))}
                </div>
                <button
                  type="submit"
                  disabled={!reportReason}
                  className="w-full py-2 bg-red-500 hover:bg-red-600 disabled:opacity-50 text-white text-sm font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
                >
                  Submit Report
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}