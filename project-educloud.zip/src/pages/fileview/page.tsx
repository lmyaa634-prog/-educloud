import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import Navbar from "@/components/feature/Navbar";
import FileViewer from "./components/FileViewer";
import RatingSection from "./components/RatingSection";
import CommentsSection from "./components/CommentsSection";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";
import { formatLevel, formatDate } from "@/lib/helpers";

const FILE_TYPE_CONFIG: Record<string, { icon: string; color: string; bg: string }> = {
  pdf: { icon: "ri-file-pdf-line", color: "text-red-600", bg: "bg-red-50" },
  ppt: { icon: "ri-file-ppt-line", color: "text-orange-600", bg: "bg-orange-50" },
  docx: { icon: "ri-file-word-line", color: "text-sky-600", bg: "bg-sky-50" },
  image: { icon: "ri-image-line", color: "text-violet-600", bg: "bg-violet-50" },
  video: { icon: "ri-video-line", color: "text-pink-600", bg: "bg-pink-50" },
};

interface FileData {
  id: number;
  title: string;
  description: string | null;
  file_type: string;
  course_name: string;
  instructor_name: string | null;
  college: string | null;
  year: number | null;
  level: number | null;
  file_url: string;
  likes: number;
  stars_avg: number | null;
  views: number;
  created_at: string;
  status: string;
  uploader_id: string;
  uploader_name: string | null;
  uploader_avatar: string | null;
  rating_count: number;
}

export default function FileViewPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [file, setFile] = useState<FileData | null>(null);
  const [relatedFiles, setRelatedFiles] = useState<FileData[]>([]);
  const [isFavorite, setIsFavorite] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [uploaderStats, setUploaderStats] = useState({ uploads: 0, avgRating: 0 });
  const [isUploader, setIsUploader] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [deleteProcessing, setDeleteProcessing] = useState(false);

  const numericId = id ? Number.parseInt(id, 10) : NaN;

  useEffect(() => {
    if (!numericId || Number.isNaN(numericId)) {
      setError("Invalid file ID.");
      setLoading(false);
      return;
    }
    loadFile();
  }, [numericId, user?.id]);

  const loadFile = async () => {
    setLoading(true);
    setError("");

    // Fetch file with uploader profile
    const { data } = await supabase
      .from("files")
      .select("*, profiles:uploader_id(full_name, avatar, id)")
      .eq("id", numericId)
      .eq("status", "approved")
      .maybeSingle();

    if (!data) {
      setError("File not found or not approved yet.");
      setLoading(false);
      return;
    }

    // Get real rating count
    const { count: ratingCount } = await supabase
      .from("ratings")
      .select("id", { count: "exact", head: true })
      .eq("file_id", numericId);

    const mapped: FileData = {
      id: data.id,
      title: data.title,
      description: data.description,
      file_type: data.file_type,
      course_name: data.course_name,
      instructor_name: data.instructor_name,
      college: data.college,
      year: data.year,
      level: data.level,
      file_url: data.file_url,
      likes: data.likes ?? 0,
      stars_avg: data.stars_avg ?? 0,
      views: data.views ?? 0,
      created_at: data.created_at,
      status: data.status,
      uploader_id: data.uploader_id,
      uploader_name: data.profiles?.full_name ?? "Unknown",
      uploader_avatar: data.profiles?.avatar ?? null,
      rating_count: ratingCount ?? 0,
    };

    setFile(mapped);
    setIsUploader(user?.id === mapped.uploader_id);

    // Check if current user favorited this file
    if (user) {
      const { data: favData } = await supabase
        .from("favorites")
        .select("id")
        .eq("file_id", numericId)
        .eq("user_id", user.id)
        .maybeSingle();
      setIsFavorite(!!favData);
    }

    // Load uploader stats
    const { count: uploadCount } = await supabase
      .from("files")
      .select("id", { count: "exact", head: true })
      .eq("uploader_id", mapped.uploader_id)
      .eq("status", "approved");

    const { data: avgData } = await supabase
      .from("files")
      .select("stars_avg")
      .eq("uploader_id", mapped.uploader_id)
      .eq("status", "approved")
      .not("stars_avg", "is", null);

    const avg =
      avgData && avgData.length > 0
        ? avgData.reduce((sum, f) => sum + (f.stars_avg ?? 0), 0) / avgData.length
        : 0;

    setUploaderStats({ uploads: uploadCount ?? 0, avgRating: Number.isFinite(avg) ? Math.round(avg * 10) / 10 : 0 });

    // Load related files from same college
    const { data: related } = await supabase
      .from("files")
      .select("*, profiles:uploader_id(full_name)")
      .eq("college", mapped.college)
      .eq("status", "approved")
      .neq("id", numericId)
      .order("stars_avg", { ascending: false })
      .limit(3);

    const mappedRelated = (related || []).map((f: any) => ({
      id: f.id,
      title: f.title,
      description: f.description,
      file_type: f.file_type,
      course_name: f.course_name,
      instructor_name: f.instructor_name,
      college: f.college,
      year: f.year,
      level: f.level,
      file_url: f.file_url,
      likes: f.likes ?? 0,
      stars_avg: f.stars_avg ?? 0,
      views: f.views ?? 0,
      created_at: f.created_at,
      status: f.status,
      uploader_id: f.uploader_id,
      uploader_name: f.profiles?.full_name ?? "Unknown",
      uploader_avatar: null,
      rating_count: 0,
    }));

    setRelatedFiles(mappedRelated);
    setLoading(false);
  };

  const handleToggleFavorite = async () => {
    if (!user || !file) return;
    if (isFavorite) {
      await supabase.from("favorites").delete().eq("file_id", file.id).eq("user_id", user.id);
      setIsFavorite(false);
    } else {
      await supabase.from("favorites").insert({ file_id: file.id, user_id: user.id });
      setIsFavorite(true);
    }
  };

  const handleDelete = async () => {
    if (!file) return;
    setDeleteProcessing(true);
    const { data: fileData } = await supabase.from("files").select("file_url").eq("id", file.id).maybeSingle();
    if (fileData?.file_url) {
      await supabase.storage.from("file_storage").remove([fileData.file_url]);
    }
    await supabase.from("files").delete().eq("id", file.id);
    setDeleteProcessing(false);
    setShowDelete(false);
    navigate("/profile");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-20 text-center">
          <div className="w-10 h-10 flex items-center justify-center mx-auto mb-3">
            <i className="ri-loader-4-line animate-spin text-sky-500 text-2xl"></i>
          </div>
          <p className="text-gray-500 text-sm">Loading file details...</p>
        </div>
      </div>
    );
  }

  if (error || !file) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-20 text-center">
          <div className="w-14 h-14 flex items-center justify-center mx-auto mb-4 bg-gray-100 rounded-full">
            <i className="ri-error-warning-line text-gray-300 text-3xl"></i>
          </div>
          <h2 className="text-lg font-semibold text-gray-700 mb-2">{error || "File not found"}</h2>
          <Link
            to="/search"
            className="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded-md transition-colors cursor-pointer inline-flex items-center gap-2"
          >
            <i className="ri-search-line text-sm"></i>
            Browse Files
          </Link>
        </div>
      </div>
    );
  }

  const typeConfig = FILE_TYPE_CONFIG[file.file_type] || FILE_TYPE_CONFIG.pdf;
  const rating = Number.isFinite(file.stars_avg) && file.stars_avg ? file.stars_avg : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-3">
          <div className="flex items-center gap-2 text-xs text-gray-500 flex-wrap">
            <Link to="/" className="hover:text-sky-500 cursor-pointer">Home</Link>
            <i className="ri-arrow-right-s-line text-gray-300"></i>
            <Link to="/search" className="hover:text-sky-500 cursor-pointer">Search</Link>
            <i className="ri-arrow-right-s-line text-gray-300"></i>
            <span className="text-gray-700 truncate max-w-xs">{file.title}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <div className="flex-1 min-w-0">
            {/* File Header */}
            <div className="bg-white rounded-lg border border-gray-100 p-6 mb-6">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 flex items-center justify-center rounded-lg flex-shrink-0 ${typeConfig.bg}`}>
                  <i className={`${typeConfig.icon} ${typeConfig.color} text-2xl`}></i>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                      <h1 className="text-xl font-bold text-gray-900 mb-1">{file.title}</h1>
                      {file.description && <p className="text-sm text-gray-500">{file.description}</p>}
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {isUploader && (
                        <button
                          onClick={() => setShowDelete(true)}
                          className="px-3 py-1.5 text-xs text-red-600 border border-red-200 rounded-md hover:bg-red-50 cursor-pointer whitespace-nowrap transition-colors"
                          title="Delete your upload"
                        >
                          <span className="flex items-center gap-1">
                            <i className="ri-delete-bin-line text-xs"></i>
                            Delete
                          </span>
                        </button>
                      )}
                      <button
                        onClick={handleToggleFavorite}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                          isFavorite
                            ? "bg-sky-50 text-sky-700 border border-sky-200"
                            : "bg-gray-50 text-gray-600 border border-gray-200 hover:bg-gray-100"
                        }`}
                      >
                        <div className="w-4 h-4 flex items-center justify-center">
                          <i className={`${isFavorite ? "ri-bookmark-fill" : "ri-bookmark-line"} text-sm`}></i>
                        </div>
                        {isFavorite ? "Saved" : "Save"}
                      </button>
                    </div>
                  </div>

                  {/* Metadata */}
                  <div className="flex flex-wrap gap-3 mt-4">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-gray-50 rounded-md text-xs text-gray-600">
                      <i className="ri-book-open-line text-xs text-gray-400"></i>
                      {file.course_name}
                    </span>
                    {file.instructor_name && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-gray-50 rounded-md text-xs text-gray-600">
                        <i className="ri-user-line text-xs text-gray-400"></i>
                        {file.instructor_name}
                      </span>
                    )}
                    {file.college && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-gray-50 rounded-md text-xs text-gray-600">
                        <i className="ri-building-line text-xs text-gray-400"></i>
                        {file.college}
                      </span>
                    )}
                    {file.level !== null && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-gray-50 rounded-md text-xs text-gray-600">
                        <i className="ri-graduation-cap-line text-xs text-gray-400"></i>
                        {formatLevel(file.level)}
                      </span>
                    )}
                    {file.year !== null && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-gray-50 rounded-md text-xs text-gray-600">
                        <i className="ri-calendar-line text-xs text-gray-400"></i>
                        {file.year}
                      </span>
                    )}
                  </div>

                  {/* Stats Row */}
                  <div className="flex items-center gap-4 mt-4 pt-4 border-t border-gray-50">
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <div key={s} className="w-3.5 h-3.5 flex items-center justify-center">
                          <i
                            className={`${
                              s <= Math.round(rating) ? "ri-star-fill" : "ri-star-line"
                            } text-amber-400 text-xs`}
                          ></i>
                        </div>
                      ))}
                      <span className="text-sm font-medium text-gray-700 ml-1">
                        {Number.isFinite(rating) ? rating.toFixed(1) : "0.0"}
                      </span>
                      <span className="text-xs text-gray-400">({file.rating_count})</span>
                    </div>
                    <span className="flex items-center gap-1 text-xs text-gray-500">
                      <i className="ri-download-line text-xs"></i>
                      {file.views.toLocaleString("en-US")} views
                    </span>
                    <span className="flex items-center gap-1 text-xs text-gray-500">
                      <i className="ri-heart-line text-xs"></i>
                      {file.likes} likes
                    </span>
                    <div className="flex items-center gap-2 ml-auto">
                      {file.uploader_avatar ? (
                        <img
                          src={file.uploader_avatar}
                          alt={file.uploader_name || ""}
                          className="w-5 h-5 rounded-full object-cover object-top"
                        />
                      ) : (
                        <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-[10px] font-semibold text-gray-500">
                          {(file.uploader_name || "U").charAt(0).toUpperCase()}
                        </div>
                      )}
                      <span className="text-xs text-gray-500">{file.uploader_name}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* File Viewer */}
            <div className="bg-white rounded-lg border border-gray-100 p-4 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-gray-900 text-sm">File Preview</h2>
              </div>
              <FileViewer fileType={file.file_type} title={file.title} fileUrl={file.file_url} />
            </div>

            {/* Rating Section */}
            <div className="mb-6">
              <RatingSection
                fileId={file.id}
                rating={Number.isFinite(rating) ? rating : 0}
                ratingCount={file.rating_count}
                likes={file.likes}
                isFavorite={isFavorite}
                onToggleFavorite={handleToggleFavorite}
              />
            </div>

            {/* Comments */}
            <CommentsSection fileId={String(file.id)} />
          </div>

          {/* Sidebar */}
          <aside className="w-full lg:w-72 flex-shrink-0">
            {/* Uploader Info */}
            <div className="bg-white rounded-lg border border-gray-100 p-5 mb-4">
              <h3 className="font-semibold text-gray-900 text-sm mb-4">Uploaded by</h3>
              <div className="flex items-center gap-3">
                {file.uploader_avatar ? (
                  <img
                    src={file.uploader_avatar}
                    alt={file.uploader_name || ""}
                    className="w-10 h-10 rounded-full object-cover object-top"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-xs font-semibold text-gray-500">
                    {(file.uploader_name || "U").charAt(0).toUpperCase()}
                  </div>
                )}
                <div>
                  <p className="text-sm font-medium text-gray-900">{file.uploader_name}</p>
                  <p className="text-xs text-gray-500">{file.college?.replace("Faculty of ", "") || "—"}</p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-50 grid grid-cols-2 gap-3">
                <div className="text-center">
                  <p className="text-lg font-bold text-gray-900">{uploaderStats.uploads}</p>
                  <p className="text-xs text-gray-500">Uploads</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold text-gray-900">
                    {Number.isFinite(uploaderStats.avgRating) ? uploaderStats.avgRating.toFixed(1) : "0.0"}
                  </p>
                  <p className="text-xs text-gray-500">Avg. Rating</p>
                </div>
              </div>
            </div>

            {/* File Info */}
            <div className="bg-white rounded-lg border border-gray-100 p-5 mb-4">
              <h3 className="font-semibold text-gray-900 text-sm mb-4">File Details</h3>
              <div className="flex flex-col gap-3">
                {[
                  { label: "Format", value: file.file_type.toUpperCase(), icon: "ri-file-line" },
                  {
                    label: "Uploaded",
                    value: formatDate(file.created_at),
                    icon: "ri-calendar-line",
                  },
                  { label: "Level", value: formatLevel(file.level), icon: "ri-graduation-cap-line" },
                  {
                    label: "Year",
                    value: file.year !== null ? String(file.year) : "—",
                    icon: "ri-time-line",
                  },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 flex items-center justify-center">
                        <i className={`${item.icon} text-gray-400 text-xs`}></i>
                      </div>
                      <span className="text-xs text-gray-500">{item.label}</span>
                    </div>
                    <span className="text-xs font-medium text-gray-700">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Related Files */}
            {relatedFiles.length > 0 && (
              <div className="bg-white rounded-lg border border-gray-100 p-5">
                <h3 className="font-semibold text-gray-900 text-sm mb-4">Related Files</h3>
                <div className="flex flex-col gap-3">
                  {relatedFiles.map((rf) => {
                    const rc = FILE_TYPE_CONFIG[rf.file_type] || FILE_TYPE_CONFIG.pdf;
                    const rfRating = Number.isFinite(rf.stars_avg) && rf.stars_avg ? rf.stars_avg : 0;
                    return (
                      <Link
                        key={rf.id}
                        to={`/file/${rf.id}`}
                        className="flex items-start gap-3 group cursor-pointer"
                      >
                        <div className={`w-8 h-8 flex items-center justify-center rounded flex-shrink-0 ${rc.bg}`}>
                          <i className={`${rc.icon} ${rc.color} text-sm`}></i>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-gray-800 group-hover:text-sky-600 transition-colors line-clamp-2">
                            {rf.title}
                          </p>
                          <div className="flex items-center gap-1 mt-0.5">
                            <i className="ri-star-fill text-amber-400 text-xs"></i>
                            <span className="text-xs text-gray-500">
                              {Number.isFinite(rfRating) ? rfRating.toFixed(1) : "0.0"}
                            </span>
                          </div>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              </div>
            )}
          </aside>
        </div>
      </div>

      {/* Delete Confirm Modal */}
      {showDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
          <div className="bg-white rounded-lg w-full max-w-sm p-6 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 flex items-center justify-center bg-red-50 rounded-full">
                <i className="ri-delete-bin-line text-red-500 text-xl"></i>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900">Delete File</h4>
                <p className="text-xs text-gray-500">This action cannot be undone</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-5">
              Are you sure you want to permanently delete "{file.title}"? It will be removed from the platform and storage immediately.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setShowDelete(false)}
                className="flex-1 py-2 border border-gray-200 text-gray-700 text-sm rounded-md hover:bg-gray-50 cursor-pointer whitespace-nowrap transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={deleteProcessing}
                className="flex-1 py-2 bg-red-500 hover:bg-red-600 disabled:opacity-60 text-white text-sm font-medium rounded-md cursor-pointer whitespace-nowrap transition-colors"
              >
                {deleteProcessing ? (
                  <span className="flex items-center justify-center gap-1">
                    <i className="ri-loader-4-line animate-spin text-xs"></i>
                    Deleting...
                  </span>
                ) : (
                  "Delete"
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}