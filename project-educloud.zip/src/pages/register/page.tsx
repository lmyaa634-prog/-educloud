import { useState, useEffect, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";

export default function RegisterPage() {
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    college: "",
    password: "",
    confirmPassword: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [agreed, setAgreed] = useState(false);
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const [liveStats, setLiveStats] = useState({ totalFiles: 0, totalStudents: 0, totalColleges: 0, avgRating: 0 });

  useEffect(() => {
    const loadStats = async () => {
      const [filesRes, usersRes] = await Promise.all([
        supabase.from("files").select("id, stars_avg, college", { count: "exact", head: false }).eq("status", "approved"),
        supabase.from("profiles").select("id", { count: "exact", head: true }),
      ]);
      const files = filesRes.data || [];
      const totalFiles = filesRes.count ?? files.length;
      const totalStudents = usersRes.count ?? 0;
      const colleges = new Set(files.map((f: any) => f.college).filter(Boolean));
      const totalColleges = colleges.size;
      const ratings = files.map((f: any) => f.stars_avg).filter((v: any) => typeof v === "number" && Number.isFinite(v));
      const avgRating = ratings.length > 0 ? ratings.reduce((a: number, b: number) => a + b, 0) / ratings.length : 0;
      setLiveStats({ totalFiles, totalStudents, totalColleges, avgRating: Number.isFinite(avgRating) ? Math.round(avgRating * 10) / 10 : 0 });
    };
    loadStats();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const getPasswordStrength = () => {
    const p = form.password;
    if (!p) return { level: 0, label: "", color: "" };
    let score = 0;
    if (p.length >= 8) score++;
    if (/[A-Z]/.test(p)) score++;
    if (/[0-9]/.test(p)) score++;
    if (/[^A-Za-z0-9]/.test(p)) score++;
    if (score <= 1) return { level: 1, label: "Weak", color: "bg-red-400" };
    if (score === 2) return { level: 2, label: "Fair", color: "bg-amber-400" };
    if (score === 3) return { level: 3, label: "Good", color: "bg-sky-400" };
    return { level: 4, label: "Strong", color: "bg-sky-600" };
  };

  const strength = getPasswordStrength();

  const [successMsg, setSuccessMsg] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccessMsg("");
    if (!form.fullName || !form.email || !form.college || !form.password || !form.confirmPassword) {
      setError("Please fill in all fields.");
      return;
    }
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (form.password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    if (!agreed) {
      setError("Please agree to the Terms of Service.");
      return;
    }
    setLoading(true);
    const { error: signUpError } = await signUp(form.email, form.password, {
      full_name: form.fullName,
      college: form.college,
    });
    setLoading(false);
    if (signUpError) {
      setError(signUpError);
      return;
    }

    // Check if auto-login succeeded
    const { data: sessionData } = await supabase.auth.getSession();
    if (sessionData.session) {
      navigate("/");
    } else {
      setSuccessMsg(
        "Account created successfully! Please check your email to confirm your address, then sign in."
      );
    }
  };

  const displayStats = useMemo(() => [
    { icon: "ri-upload-cloud-line", value: liveStats.totalFiles > 0 ? `${liveStats.totalFiles.toLocaleString("en-US")}+` : "—", label: "Files Uploaded" },
    { icon: "ri-user-line", value: liveStats.totalStudents > 0 ? `${liveStats.totalStudents.toLocaleString("en-US")}+` : "—", label: "Active Students" },
    { icon: "ri-building-line", value: liveStats.totalColleges > 0 ? String(liveStats.totalColleges) : "—", label: "Colleges" },
    { icon: "ri-star-line", value: liveStats.avgRating > 0 ? liveStats.avgRating.toFixed(1) : "—", label: "Avg. Rating" },
  ], [liveStats]);

  return (
    <div className="min-h-screen flex">
      {/* Left Panel */}
      <div
        className="hidden lg:flex lg:w-1/2 relative flex-col justify-between p-12"
        style={{ background: "linear-gradient(135deg, #0c4a6e 0%, #0369a1 40%, #0ea5e9 100%)" }}
      >
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "url('https://readdy.ai/api/search-image?query=abstract%20flowing%20lines%20and%20particles%20on%20deep%20blue%20background%20representing%20knowledge%20sharing%20and%20academic%20collaboration%20minimal%20elegant%20pattern&width=800&height=1200&seq=register-bg-sky-01&orientation=portrait')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            opacity: 0.15,
          }}
        />
        <div className="relative z-10">
          <img
            src="https://public.readdy.ai/ai/img_res/a6ed7123-3e38-48c9-bc60-c18c9390c0fa.png"
            alt="StudyHub"
            className="h-12 w-auto object-contain brightness-0 invert"
          />
        </div>
        <div className="relative z-10">
          <h2 className="text-3xl font-bold text-white leading-tight mb-4">
            Join thousands of students sharing knowledge.
          </h2>
          <p className="text-sky-200 text-base leading-relaxed mb-8">
            Upload your notes, discover quality materials, and help your peers succeed — all in one organized platform.
          </p>
          <div className="grid grid-cols-2 gap-4">
            {displayStats.map((stat) => (
              <div key={stat.label} className="bg-white/10 rounded-lg p-4">
                <div className="w-8 h-8 flex items-center justify-center mb-2">
                  <i className={`${stat.icon} text-sky-300 text-lg`}></i>
                </div>
                <p className="text-white font-bold text-xl">{stat.value}</p>
                <p className="text-sky-300 text-xs">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="relative z-10">
          <blockquote className="text-sky-100 text-sm italic leading-relaxed">
            &ldquo;educloud completely changed how I prepare for exams. I found summaries for every course in my faculty.&rdquo;
          </blockquote>
          <p className="text-sky-300 text-xs mt-2">— Sara M., 3rd Year Engineering</p>
        </div>
      </div>

      {/* Right Panel */}
      <div className="flex-1 flex items-center justify-center px-6 py-12 bg-white overflow-y-auto">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex justify-center mb-8">
            <img
              src="https://public.readdy.ai/ai/img_res/a6ed7123-3e38-48c9-bc60-c18c9390c0fa.png"
              alt="StudyHub"
              className="h-10 w-auto object-contain"
            />
          </div>

          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-900 mb-1">Create your account</h1>
            <p className="text-gray-500 text-sm">Join the academic community — it&apos;s free</p>
          </div>

          {error && (
            <div className="mb-4 px-4 py-3 rounded-lg bg-red-50 border border-red-100 flex items-start gap-2">
              <i className="ri-error-warning-line text-red-500 text-sm mt-0.5"></i>
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 px-4 py-3 rounded-lg bg-sky-50 border border-sky-100 flex items-start gap-2">
              <i className="ri-checkbox-circle-line text-sky-500 text-sm mt-0.5"></i>
              <p className="text-sky-700 text-sm">{successMsg}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {/* Full Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                  <i className="ri-user-line text-gray-400 text-sm"></i>
                </div>
                <input
                  type="text"
                  name="fullName"
                  value={form.fullName}
                  onChange={handleChange}
                  placeholder="Ahmed Al-Rashid"
                  className="w-full pl-9 pr-4 py-2.5 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">University Email</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                  <i className="ri-mail-line text-gray-400 text-sm"></i>
                </div>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="you@university.edu"
                  className="w-full pl-9 pr-4 py-2.5 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* College */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">College / Faculty</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                  <i className="ri-building-line text-gray-400 text-sm"></i>
                </div>
                <input
                  type="text"
                  name="college"
                  value={form.college}
                  onChange={handleChange}
                  placeholder="e.g. Faculty of Engineering"
                  className="w-full pl-9 pr-4 py-2.5 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                  <i className="ri-lock-line text-gray-400 text-sm"></i>
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={form.password}
                  onChange={handleChange}
                  placeholder="Min. 8 characters"
                  className="w-full pl-9 pr-10 py-2.5 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <i className={`text-sm ${showPassword ? "ri-eye-off-line" : "ri-eye-line"}`}></i>
                </button>
              </div>
              {form.password && (
                <div className="mt-2">
                  <div className="flex gap-1 mb-1">
                    {[1, 2, 3, 4].map((i) => (
                      <div
                        key={i}
                        className={`h-1 flex-1 rounded-full transition-all ${
                          i <= strength.level ? strength.color : "bg-gray-200"
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-xs text-gray-500">
                    Password strength: <span className="font-medium">{strength.label}</span>
                  </p>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Confirm Password</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                  <i className="ri-lock-2-line text-gray-400 text-sm"></i>
                </div>
                <input
                  type={showConfirm ? "text" : "password"}
                  name="confirmPassword"
                  value={form.confirmPassword}
                  onChange={handleChange}
                  placeholder="Re-enter your password"
                  className={`w-full pl-9 pr-10 py-2.5 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent transition-all ${
                    form.confirmPassword && form.confirmPassword !== form.password
                      ? "border-red-300"
                      : "border-gray-200"
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <i className={`text-sm ${showConfirm ? "ri-eye-off-line" : "ri-eye-line"}`}></i>
                </button>
              </div>
              {form.confirmPassword && form.confirmPassword !== form.password && (
                <p className="text-xs text-red-500 mt-1">Passwords do not match</p>
              )}
            </div>

            {/* Role badge */}
            <div className="flex items-center gap-2 px-3 py-2.5 bg-sky-50 rounded-md border border-sky-100">
              <div className="w-5 h-5 flex items-center justify-center">
                <i className="ri-graduation-cap-line text-sky-500 text-sm"></i>
              </div>
              <p className="text-sm text-sky-700">
                Your account will be registered as a <strong>Student</strong>
              </p>
            </div>

            {/* Terms */}
            <div className="flex items-start gap-2">
              <input
                type="checkbox"
                id="terms"
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                className="w-4 h-4 mt-0.5 rounded border-gray-300 text-sky-500 focus:ring-sky-400 cursor-pointer"
              />
              <label htmlFor="terms" className="text-sm text-gray-600 cursor-pointer leading-relaxed">
                I agree to the{" "}
                <Link to="/terms" className="text-sky-500 hover:text-sky-600">Terms of Service</Link>
                {" "}and{" "}
                <Link to="/privacy" className="text-sky-500 hover:text-sky-600">Privacy Policy</Link>
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 text-sm font-semibold text-white bg-sky-500 hover:bg-sky-600 disabled:opacity-60 rounded-md transition-colors cursor-pointer whitespace-nowrap mt-1"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <i className="ri-loader-4-line animate-spin text-sm"></i>
                  Creating account...
                </span>
              ) : (
                "Create Account"
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500">
              Already have an account?{" "}
              <Link to="/login" className="text-sky-500 font-medium hover:text-sky-600 cursor-pointer">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}