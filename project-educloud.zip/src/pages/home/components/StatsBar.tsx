import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

export default function StatsBar() {
  const [stats, setStats] = useState({
    totalFiles: 0,
    totalStudents: 0,
    totalColleges: 0,
    avgRating: 0,
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    const [filesRes, usersRes] = await Promise.all([
      supabase.from("files").select("id, stars_avg, college", { count: "exact", head: false }).eq("status", "approved"),
      supabase.from("profiles").select("id", { count: "exact", head: true }),
    ]);

    const files = filesRes.data || [];
    const totalFiles = filesRes.count ?? files.length;
    const totalStudents = usersRes.count ?? 0;

    const colleges = new Set(files.map((f: any) => f.college).filter(Boolean));
    const totalColleges = colleges.size;

    const ratings = files.map((f: any) => f.stars_avg).filter((v: any) => typeof v === "number" && Number.isFinite(v));
    const avgRating = ratings.length > 0 ? ratings.reduce((a: number, b: number) => a + b, 0) / ratings.length : 0;

    setStats({
      totalFiles,
      totalStudents,
      totalColleges,
      avgRating: Number.isFinite(avgRating) ? Math.round(avgRating * 10) / 10 : 0,
    });
  };

  const displayStats = [
    { icon: "ri-file-text-line", value: stats.totalFiles.toLocaleString("en-US") + "+", label: "Academic Files" },
    { icon: "ri-user-line", value: stats.totalStudents.toLocaleString("en-US") + "+", label: "Active Students" },
    { icon: "ri-building-line", value: stats.totalColleges.toString(), label: "Colleges" },
    { icon: "ri-star-fill", value: stats.avgRating.toFixed(1), label: "Avg. Rating" },
  ];

  return (
    <section className="bg-sky-600">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-0 md:divide-x md:divide-sky-500">
          {displayStats.map((stat) => (
            <div key={stat.label} className="flex items-center gap-3 md:px-8 first:pl-0 last:pr-0">
              <div className="w-9 h-9 flex items-center justify-center rounded-lg bg-sky-500">
                <i className={`${stat.icon} text-sky-100 text-base`}></i>
              </div>
              <div>
                <p className="text-white font-bold text-lg leading-none">{stat.value}</p>
                <p className="text-sky-200 text-xs mt-0.5">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}