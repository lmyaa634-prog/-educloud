import { Link } from "react-router-dom";
import { formatLevel } from "@/lib/helpers";

interface FileCardProps {
  file: {
    id: number;
    title: string;
    description: string | null;
    file_type: string;
    course_name: string;
    instructor_name: string | null;
    college: string | null;
    level: number | null;
    stars_avg: number | null;
    likes: number;
    views: number;
    uploader_name: string | null;
    uploader_avatar: string | null;
  };
}

const FILE_TYPE_CONFIG: Record<string, { icon: string; color: string; bg: string }> = {
  pdf: { icon: "ri-file-pdf-line", color: "text-red-600", bg: "bg-red-50" },
  ppt: { icon: "ri-file-ppt-line", color: "text-orange-600", bg: "bg-orange-50" },
  docx: { icon: "ri-file-word-line", color: "text-sky-600", bg: "bg-sky-50" },
  image: { icon: "ri-image-line", color: "text-violet-600", bg: "bg-violet-50" },
  video: { icon: "ri-video-line", color: "text-pink-600", bg: "bg-pink-50" },
};

function StarRating({ rating }: { rating: number }) {
  const rounded = Math.round(rating);
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <div key={star} className="w-3 h-3 flex items-center justify-center">
          <i
            className={`${
              star <= rounded ? "ri-star-fill" : "ri-star-line"
            } text-amber-400 text-xs`}
          ></i>
        </div>
      ))}
    </div>
  );
}

export default function FileCard({ file }: FileCardProps) {
  const typeConfig = FILE_TYPE_CONFIG[file.file_type] || FILE_TYPE_CONFIG.pdf;
  const rating = Number.isFinite(file.stars_avg) && file.stars_avg ? file.stars_avg : 0;

  return (
    <Link
      to={`/file/${file.id}`}
      className="group bg-white rounded-lg border border-gray-100 overflow-hidden hover:border-sky-200 transition-all cursor-pointer block"
    >
      {/* Type Banner */}
      <div className={`${typeConfig.bg} px-4 py-3 flex items-center gap-2`}>
        <div className="w-6 h-6 flex items-center justify-center">
          <i className={`${typeConfig.icon} ${typeConfig.color} text-lg`}></i>
        </div>
        <span className={`text-xs font-semibold ${typeConfig.color}`}>{file.file_type.toUpperCase()}</span>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="text-sm font-semibold text-gray-900 leading-snug mb-1 line-clamp-2 group-hover:text-sky-600 transition-colors">
          {file.title}
        </h3>
        {file.description && <p className="text-xs text-gray-500 mb-3 line-clamp-2">{file.description}</p>}

        {/* Meta */}
        <div className="flex flex-col gap-1 mb-3">
          <div className="flex items-center gap-1.5">
            <div className="w-3.5 h-3.5 flex items-center justify-center">
              <i className="ri-book-open-line text-gray-400 text-xs"></i>
            </div>
            <span className="text-xs text-gray-600 truncate">{file.course_name}</span>
          </div>
          {file.instructor_name && (
            <div className="flex items-center gap-1.5">
              <div className="w-3.5 h-3.5 flex items-center justify-center">
                <i className="ri-user-line text-gray-400 text-xs"></i>
              </div>
              <span className="text-xs text-gray-600 truncate">{file.instructor_name}</span>
            </div>
          )}
          {file.college && (
            <div className="flex items-center gap-1.5">
              <div className="w-3.5 h-3.5 flex items-center justify-center">
                <i className="ri-building-line text-gray-400 text-xs"></i>
              </div>
              <span className="text-xs text-gray-500 truncate">{file.college}</span>
            </div>
          )}
        </div>

        {/* Rating & Stats */}
        <div className="flex items-center justify-between pt-3 border-t border-gray-50">
          <div className="flex items-center gap-1.5">
            <StarRating rating={rating} />
            <span className="text-xs font-medium text-gray-700">
              {Number.isFinite(rating) ? rating.toFixed(1) : "0.0"}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-0.5">
              <div className="w-3.5 h-3.5 flex items-center justify-center">
                <i className="ri-eye-line text-gray-400 text-xs"></i>
              </div>
              <span className="text-xs text-gray-500">
                {file.views >= 1000 ? `${(file.views / 1000).toFixed(1)}k` : file.views}
              </span>
            </div>
            <div className="flex items-center gap-0.5">
              <div className="w-3.5 h-3.5 flex items-center justify-center">
                <i className="ri-heart-line text-gray-400 text-xs"></i>
              </div>
              <span className="text-xs text-gray-500">{file.likes}</span>
            </div>
          </div>
        </div>

        {/* Uploader */}
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-50">
          {file.uploader_avatar ? (
            <img
              src={file.uploader_avatar}
              alt={file.uploader_name || ""}
              className="w-5 h-5 rounded-full object-cover object-top"
            />
          ) : (
            <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-[10px] font-semibold text-gray-500">
              {(file.uploader_name || "U").charAt(0).toUpperCase()}
            </div>
          )}
          <span className="text-xs text-gray-500">{file.uploader_name || "Unknown"}</span>
          {file.level !== null && (
            <span className="text-xs text-gray-400 ml-auto">{formatLevel(file.level)}</span>
          )}
        </div>
      </div>
    </Link>
  );
}