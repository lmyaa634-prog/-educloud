interface CollegeFilterProps {
  selected: string;
  onChange: (college: string) => void;
}

const colleges = [
  { label: "All", value: "" },
  { label: "Engineering", value: "Faculty of Engineering" },
  { label: "Medicine", value: "Faculty of Medicine" },
  { label: "Science", value: "Faculty of Science" },
  { label: "Commerce", value: "Faculty of Commerce" },
  { label: "Law", value: "Faculty of Law" },
  { label: "Pharmacy", value: "Faculty of Pharmacy" },
  { label: "Computer Science", value: "Faculty of Computer Science" },
];

export default function CollegeFilter({ selected, onChange }: CollegeFilterProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {colleges.map((c) => (
        <button
          key={c.value}
          onClick={() => onChange(c.value)}
          className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
            selected === c.value
              ? "bg-sky-500 text-white"
              : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          {c.label}
        </button>
      ))}
    </div>
  );
}
