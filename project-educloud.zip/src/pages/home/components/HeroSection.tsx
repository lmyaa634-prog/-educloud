import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function HeroSection() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  };

  const quickSearches = ["Thermodynamics", "Organic Chemistry", "Data Structures", "Anatomy", "Calculus"];

  return (
    <section className="relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://readdy.ai/api/search-image?query=university%20library%20interior%20with%20bookshelves%20warm%20lighting%20students%20studying%20academic%20atmosphere%20wide%20angle%20shot%20beautiful%20architecture%20light%20blue%20tones&width=1440&height=600&seq=hero-bg-sky-02&orientation=landscape"
          alt="Academic library"
          className="w-full h-full object-cover object-top"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-sky-900/85 via-sky-800/75 to-sky-700/60"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-6 py-20 md:py-28">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white/10 backdrop-blur-sm rounded-full border border-white/20 mb-6">
            <div className="w-4 h-4 flex items-center justify-center">
              <i className="ri-graduation-cap-line text-sky-300 text-xs"></i>
            </div>
            <span className="text-sky-100 text-xs font-medium">The EduCloud Knowledge Hub</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-white leading-tight mb-4">
            Find, Share &amp; Master<br />
            <span className="text-sky-300">Academic Materials</span>
          </h1>
          <p className="text-sky-100 text-base md:text-lg leading-relaxed mb-8">
            Access thousands of approved lectures, summaries, and revision files from students across your university — all in one organized, searchable place.
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="flex gap-2 mb-4">
            <div className="flex-1 relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                <i className="ri-search-line text-gray-400 text-sm"></i>
              </div>
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by course, instructor, or topic..."
                className="w-full pl-11 pr-4 py-3.5 text-sm bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-300 text-gray-800 placeholder-gray-400"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3.5 bg-sky-500 hover:bg-sky-400 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              Search
            </button>
          </form>

          {/* Quick Searches */}
          <div className="flex flex-wrap gap-2">
            <span className="text-sky-300 text-xs">Popular:</span>
            {quickSearches.map((term) => (
              <button
                key={term}
                onClick={() => navigate(`/search?q=${encodeURIComponent(term)}`)}
                className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white text-xs rounded-full border border-white/20 transition-colors cursor-pointer whitespace-nowrap"
              >
                {term}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
