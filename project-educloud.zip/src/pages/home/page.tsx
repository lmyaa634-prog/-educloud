import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/feature/Navbar";
import HeroSection from "./components/HeroSection";
import StatsBar from "./components/StatsBar";
import FileCard from "./components/FileCard";
import CollegeFilter from "./components/CollegeFilter";
import { supabase } from "@/lib/supabase";
import { formatLevel } from "@/lib/helpers";

interface HomeFile {
  id: number;
  title: string;
  description: string | null;
  file_type: string;
  course_name: string;
  instructor_name: string | null;
  college: string | null;
  year: number | null;
  level: number | null;
  stars_avg: number | null;
  likes: number;
  views: number;
  created_at: string;
  uploader_name: string | null;
  uploader_avatar: string | null;
}

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<"popular" | "recent">("popular");
  const [collegeFilter, setCollegeFilter] = useState("");
  const [files, setFiles] = useState<HomeFile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFiles();
  }, [activeTab, collegeFilter]);

  const loadFiles = async () => {
    setLoading(true);

    let dbQuery = supabase
      .from("files")
      .select("*, profiles:uploader_id(full_name, avatar)")
      .eq("status", "approved");

    if (collegeFilter) {
      dbQuery = dbQuery.eq("college", collegeFilter);
    }

    if (activeTab === "popular") {
      dbQuery = dbQuery.order("views", { ascending: false });
    } else {
      dbQuery = dbQuery.order("created_at", { ascending: false });
    }

    dbQuery = dbQuery.limit(8);

    const { data } = await dbQuery;

    const mapped: HomeFile[] = (data || []).map((f: any) => ({
      id: f.id,
      title: f.title,
      description: f.description,
      file_type: f.file_type,
      course_name: f.course_name,
      instructor_name: f.instructor_name,
      college: f.college,
      year: f.year,
      level: f.level,
      stars_avg: f.stars_avg,
      likes: f.likes ?? 0,
      views: f.views ?? 0,
      created_at: f.created_at,
      uploader_name: f.profiles?.full_name ?? "Unknown",
      uploader_avatar: f.profiles?.avatar ?? null,
    }));

    setFiles(mapped);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <HeroSection />
      <StatsBar />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 md:px-6 py-10">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Browse Materials</h2>
            <p className="text-sm text-gray-500 mt-0.5">Discover quality-approved academic resources</p>
          </div>
          {/* Tab Switcher */}
          <div className="inline-flex items-center bg-gray-100 rounded-full px-1 py-1 gap-1">
            <button
              onClick={() => setActiveTab("popular")}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === "popular"
                  ? "bg-white text-gray-900"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <span className="flex items-center gap-1.5">
                <i className="ri-fire-line text-xs"></i>
                Most Popular
              </span>
            </button>
            <button
              onClick={() => setActiveTab("recent")}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === "recent"
                  ? "bg-white text-gray-900"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <span className="flex items-center gap-1.5">
                <i className="ri-time-line text-xs"></i>
                Most Recent
              </span>
            </button>
          </div>
        </div>

        {/* College Filter */}
        <div className="mb-6">
          <CollegeFilter selected={collegeFilter} onChange={setCollegeFilter} />
        </div>

        {/* File Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <div className="flex items-center gap-2 text-gray-400">
              <i className="ri-loader-4-line animate-spin text-xl"></i>
              <span className="text-sm">Loading files...</span>
            </div>
          </div>
        ) : files.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {files.map((file) => (
              <FileCard key={file.id} file={file} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <i className="ri-folder-open-line text-gray-300 text-4xl"></i>
            </div>
            <p className="text-gray-500 text-sm">
              {collegeFilter ? "No files found for this college yet." : "No approved files available yet."}
            </p>
          </div>
        )}

        {/* View All */}
        <div className="text-center mt-8">
          <Link
            to="/search"
            className="inline-flex items-center gap-2 px-6 py-2.5 border border-sky-500 text-sky-500 hover:bg-sky-50 rounded-md text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
          >
            View All Materials
            <i className="ri-arrow-right-line text-sm"></i>
          </Link>
        </div>

        {/* CTA Banner */}
        <div className="mt-14 rounded-xl overflow-hidden relative">
          <img
            src="https://readdy.ai/api/search-image?query=students%20collaborating%20studying%20together%20university%20campus%20warm%20light%20blue%20tones%20academic%20teamwork%20modern%20library%20setting&width=1200&height=280&seq=cta-banner-sky-02&orientation=landscape"
            alt="Share knowledge"
            className="w-full h-48 object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-sky-900/80 to-sky-700/60 flex items-center">
            <div className="px-8 md:px-12 w-full">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <h3 className="text-xl font-bold text-white mb-1">Have great notes? Share them!</h3>
                  <p className="text-sky-200 text-sm">Help someone out and let your work speak for you</p>
                </div>
                <Link
                  to="/upload"
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-white text-sky-600 hover:bg-sky-50 rounded-md text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-upload-cloud-line text-sm"></i>
                  Upload a File
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-sky-900 mt-16">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <div>
              <img
                src="https://public.readdy.ai/ai/img_res/5a41cca2-fcd6-49b2-9cb5-98ec4823a351.png"
                alt="StudyHub"
                className="h-9 w-auto object-contain brightness-0 invert mb-3"
              />
              <p className="text-sky-300 text-sm leading-relaxed">
                The academic knowledge hub for university students. Share, discover, and learn together.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold text-sm mb-3">Platform</h4>
              <ul className="flex flex-col gap-2">
                {[
                  { label: "Home", to: "/" },
                  { label: "Search Files", to: "/search" },
                  { label: "Upload", to: "/upload" },
                  { label: "Profile", to: "/profile" },
                ].map((item) => (
                  <li key={item.label}>
                    <Link
                      to={item.to}
                      className="text-sky-400 hover:text-white text-sm transition-colors cursor-pointer"
                    >
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold text-sm mb-3">Colleges</h4>
              <ul className="flex flex-col gap-2">
                {["Engineering", "Medicine", "Science", "Commerce", "Law"].map((item) => (
                  <li key={item}>
                    <a href="#" className="text-sky-400 hover:text-white text-sm transition-colors cursor-pointer">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold text-sm mb-3">Support</h4>
              <ul className="flex flex-col gap-2">
                <li>
                  <a href="#" className="text-sky-400 hover:text-white text-sm transition-colors cursor-pointer">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sky-400 hover:text-white text-sm transition-colors cursor-pointer">
                    Report Content
                  </a>
                </li>
                <li>
                  <Link
                    to="/privacy"
                    className="text-sky-400 hover:text-white text-sm transition-colors cursor-pointer"
                  >
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link
                    to="/terms"
                    className="text-sky-400 hover:text-white text-sm transition-colors cursor-pointer"
                  >
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-sky-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-sky-500 text-xs">&copy; 2026 Educloud. All rights reserved. Qassim University student project.</p>
            <p className="text-sky-500 text-xs">Built for students, by Qassim University students.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}