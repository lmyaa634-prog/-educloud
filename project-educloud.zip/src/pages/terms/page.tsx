import Navbar from "@/components/feature/Navbar";

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <main className="max-w-3xl mx-auto px-4 md:px-6 py-10 md:py-16">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Terms of Service</h1>
          <p className="text-sm text-gray-500">Last updated: May 2026</p>
        </div>

        <div className="prose prose-sm max-w-none text-gray-700 leading-relaxed space-y-6">
          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">1. Acceptance of Terms</h2>
            <p>
              By accessing EduCloud, you agree to these Terms of Service. If you do not agree, do not use the platform.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">2. Eligibility & Registration</h2>
            <p>
              The platform is for currently enrolled university students. You must register with accurate information, including your real name and valid university email.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">3. User Content</h2>
            <p>
              You retain ownership of files you upload. By uploading, you grant EduCloud a limited license to display and distribute your content within the platform for educational purposes. You are solely responsible for the accuracy and legality of your uploads.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">4. Prohibited Content</h2>
            <ul className="list-disc pl-5 space-y-1.5">
              <li>Copyrighted material without proper authorization.</li>
              <li>Malware, harmful files, or content designed to steal data.</li>
              <li>Personal data or private information about others without consent.</li>
              <li>Defamatory, discriminatory, harassing, or abusive content.</li>
              <li>Spam or content that misleads about its academic relevance.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">5. Content Moderation</h2>
            <p>
              All uploads are subject to admin review before becoming public. Admins may approve, reject, or remove any content without prior notice. You may delete your own uploads from your profile at any time.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">6. Ratings & Comments</h2>
            <p>
              Ratings and comments must be honest and respectful. Abuse of the rating system, including fake reviews or coordinated downvoting, is prohibited and may result in account restrictions.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">7. Account Termination</h2>
            <p>
              We may suspend or terminate accounts that violate these terms, engage in abuse, or repeatedly submit false reports. You may also delete your own account at any time from your profile settings.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">8. Intellectual Property</h2>
            <p>
              EduCloud respects intellectual property. If you believe content infringes your rights, submit a report through the Report Content feature with supporting evidence.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">9. Disclaimer</h2>
            <p>
              The platform is provided &ldquo;as is&rdquo; for educational collaboration. We do not guarantee the accuracy of user-submitted materials and are not liable for academic outcomes based on their use.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">10. Changes to Terms</h2>
            <p>
              We may update these terms at any time. Significant changes will be communicated via email or a platform notice. Continued use constitutes acceptance of the revised terms.
            </p>
          </section>
        </div>
      </main>

      <footer className="border-t border-gray-100 py-6">
        <div className="max-w-3xl mx-auto px-4 md:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-gray-400">&copy; 2026 EduCloud. All rights reserved.</p>
          <p className="text-xs text-gray-400">Qassim University student project.</p>
        </div>
      </footer>
    </div>
  );
}