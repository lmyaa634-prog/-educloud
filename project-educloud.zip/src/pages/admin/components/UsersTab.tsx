import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

type UserStatus = "active" | "banned";
type UserRole = "student" | "moderator" | "admin";

interface User {
  id: string;
  name: string;
  email: string;
  college: string | null;
  role: UserRole;
  status: UserStatus;
  uploads: number;
  joinedAt: string;
  avatar: string | null;
}

const ROLE_OPTIONS: UserRole[] = ["student", "moderator", "admin"];

const emptyForm = {
  name: "",
  email: "",
  college: "",
  role: "student" as UserRole,
  academicLevel: "",
};

export default function UsersTab({ onStatsChange }: { onStatsChange?: () => void }) {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [confirmBan, setConfirmBan] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState("");
  const [addSuccess, setAddSuccess] = useState(false);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    const { data } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });

    const userList: User[] = [];
    for (const p of data || []) {
      const { count } = await supabase.from("files").select("id", { count: "exact", head: true }).eq("uploader_id", p.id);
      userList.push({
        id: p.id,
        name: p.full_name || "Unknown",
        email: p.email,
        college: p.college,
        role: (p.role as UserRole) || "student",
        status: (p.status as UserStatus) || "active",
        uploads: count ?? 0,
        joinedAt: p.created_at?.split("T")[0] ?? "",
        avatar: p.avatar,
      });
    }
    setUsers(userList);
    setLoading(false);
  };

  const handleToggleBan = async (id: string) => {
    const target = users.find((u) => u.id === id);
    if (!target) return;
    const newStatus = target.status === "banned" ? "active" : "banned";
    await supabase.from("profiles").update({ status: newStatus }).eq("id", id);
    setConfirmBan(null);
    await loadUsers();
    onStatsChange?.();
  };

  const handleAddUser = async () => {
    if (!form.name.trim() || !form.email.trim() || !form.college.trim()) {
      setFormError("Please fill in all required fields.");
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(form.email)) {
      setFormError("Please enter a valid email address.");
      return;
    }
    if (users.some((u) => u.email.toLowerCase() === form.email.toLowerCase())) {
      setFormError("A user with this email already exists.");
      return;
    }
    setProcessing(true);

    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: form.email.trim(),
      password: "tempPassword123!",
      email_confirm: true,
    });

    if (authError || !authData.user) {
      setFormError(authError?.message || "Failed to create user account.");
      setProcessing(false);
      return;
    }

    const uid = authData.user.id;
    await supabase.from("profiles").update({
      full_name: form.name.trim(),
      college: form.college.trim(),
      level: form.academicLevel || null,
      role: form.role,
    }).eq("id", uid);

    setProcessing(false);
    setForm(emptyForm);
    setFormError("");
    setShowAddModal(false);
    setAddSuccess(true);
    setTimeout(() => setAddSuccess(false), 3000);
    await loadUsers();
    onStatsChange?.();
  };

  const handleCloseModal = () => {
    setShowAddModal(false);
    setForm(emptyForm);
    setFormError("");
  };

  const filtered = users.filter(
    (u) =>
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase()) ||
      (u.college ?? "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      {/* Success toast */}
      {addSuccess && (
        <div className="fixed top-5 right-5 z-50 bg-white border border-sky-200 rounded-lg px-4 py-3 flex items-center gap-3 shadow-sm">
          <div className="w-6 h-6 flex items-center justify-center bg-sky-50 rounded-full">
            <i className="ri-check-line text-sky-500 text-sm"></i>
          </div>
          <span className="text-sm text-gray-700 font-medium">User added successfully!</span>
        </div>
      )}

      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div>
          <h2 className="font-semibold text-gray-900">User Management</h2>
          <p className="text-sm text-gray-500 mt-0.5">{users.length} registered users</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 flex items-center justify-center">
              <i className="ri-search-line text-gray-400 text-xs"></i>
            </div>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search users..."
              className="pl-8 pr-4 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400 w-56"
            />
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white text-sm font-medium rounded-md cursor-pointer whitespace-nowrap transition-colors"
          >
            <div className="w-4 h-4 flex items-center justify-center">
              <i className="ri-user-add-line text-sm"></i>
            </div>
            Add User
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <i className="ri-loader-4-line animate-spin text-sky-500 text-2xl"></i>
        </div>
      ) : (
        <div className="bg-white rounded-lg border border-gray-100 overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">User</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden md:table-cell">College</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden sm:table-cell">Role</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden sm:table-cell">Uploads</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map((user) => (
                <tr key={user.id} className={`${user.status === "banned" ? "bg-red-50/30" : ""}`}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      {user.avatar ? (
                        <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover object-top flex-shrink-0" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-xs font-semibold text-gray-500 flex-shrink-0">
                          {user.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <p className="text-sm font-medium text-gray-900">{user.name}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <span className="text-xs text-gray-600">{user.college?.replace("Faculty of ", "") || "—"}</span>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium capitalize ${
                      user.role === "admin" ? "bg-amber-50 text-amber-700" :
                      user.role === "moderator" ? "bg-violet-50 text-violet-700" :
                      "bg-gray-100 text-gray-600"
                    }`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <span className="text-xs text-gray-600">{user.uploads} files</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      user.status === "banned" ? "bg-red-50 text-red-700" : "bg-sky-50 text-sky-700"
                    }`}>
                      {user.status === "banned" ? "Banned" : "Active"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => setConfirmBan(user.id)}
                      className={`px-3 py-1.5 text-xs rounded-md cursor-pointer whitespace-nowrap transition-colors ${
                        user.status === "banned"
                          ? "text-sky-500 border border-sky-200 hover:bg-sky-50"
                          : "text-red-600 border border-red-200 hover:bg-red-50"
                      }`}
                    >
                      {user.status === "banned" ? "Unban" : "Ban"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-8 text-gray-400 text-sm">No users found.</div>
          )}
        </div>
      )}

      {/* Add User Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 flex items-center justify-center bg-sky-50 rounded-full">
                  <i className="ri-user-add-line text-sky-500"></i>
                </div>
                <h4 className="font-semibold text-gray-900">Add New User</h4>
              </div>
              <button
                onClick={handleCloseModal}
                className="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-gray-600 cursor-pointer rounded-md hover:bg-gray-100 transition-colors"
              >
                <i className="ri-close-line"></i>
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  placeholder="e.g. Ahmed Al-Rashid"
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                  placeholder="e.g. ahmed@university.edu"
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  College / Faculty <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={form.college}
                  onChange={(e) => setForm((f) => ({ ...f, college: e.target.value }))}
                  placeholder="e.g. Faculty of Engineering"
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Role</label>
                <div className="flex gap-2">
                  {ROLE_OPTIONS.map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setForm((f) => ({ ...f, role: r }))}
                      className={`flex-1 py-2 text-xs font-medium rounded-md border cursor-pointer whitespace-nowrap capitalize transition-colors ${
                        form.role === r
                          ? r === "admin"
                            ? "bg-amber-500 border-amber-500 text-white"
                            : r === "moderator"
                            ? "bg-violet-500 border-violet-500 text-white"
                            : "bg-sky-500 border-sky-500 text-white"
                          : "border-gray-200 text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">Academic Level</label>
                <div className="flex flex-wrap gap-2">
                  {["1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year", "Graduate"].map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setForm((f) => ({ ...f, academicLevel: f.academicLevel === lvl ? "" : lvl }))}
                      className={`px-3 py-1.5 text-xs rounded-full border cursor-pointer whitespace-nowrap transition-colors ${
                        form.academicLevel === lvl
                          ? "bg-sky-500 border-sky-500 text-white"
                          : "border-gray-200 text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              {formError && (
                <div className="flex items-center gap-2 bg-red-50 border border-red-100 rounded-md px-3 py-2">
                  <div className="w-4 h-4 flex items-center justify-center flex-shrink-0">
                    <i className="ri-error-warning-line text-red-500 text-sm"></i>
                  </div>
                  <p className="text-xs text-red-600">{formError}</p>
                </div>
              )}
            </div>

            <div className="flex gap-2 mt-6">
              <button
                onClick={handleCloseModal}
                className="flex-1 py-2 border border-gray-200 text-gray-700 text-sm rounded-md hover:bg-gray-50 cursor-pointer whitespace-nowrap transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddUser}
                disabled={processing}
                className="flex-1 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-sm font-medium rounded-md cursor-pointer whitespace-nowrap transition-colors"
              >
                {processing ? (
                  <span className="flex items-center justify-center gap-1">
                    <i className="ri-loader-4-line animate-spin text-xs"></i>
                    Adding...
                  </span>
                ) : (
                  "Add User"
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Ban Modal */}
      {confirmBan && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-sm p-6">
            {(() => {
              const user = users.find((u) => u.id === confirmBan);
              const isBanned = user?.status === "banned";
              return (
                <>
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-10 h-10 flex items-center justify-center rounded-full ${isBanned ? "bg-sky-50" : "bg-red-50"}`}>
                      <i className={`${isBanned ? "ri-user-follow-line text-sky-500" : "ri-user-forbid-line text-red-500"} text-xl`}></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{isBanned ? "Unban User" : "Ban User"}</h4>
                      <p className="text-xs text-gray-500">{user?.name}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-5">
                    {isBanned
                      ? "This will restore the user's access to the platform."
                      : "This will prevent the user from accessing the platform and uploading files."}
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setConfirmBan(null)}
                      className="flex-1 py-2 border border-gray-200 text-gray-700 text-sm rounded-md hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleToggleBan(confirmBan)}
                      className={`flex-1 py-2 text-white text-sm font-medium rounded-md cursor-pointer whitespace-nowrap ${isBanned ? "bg-sky-500 hover:bg-sky-600" : "bg-red-500 hover:bg-red-600"}`}
                    >
                      {isBanned ? "Confirm Unban" : "Confirm Ban"}
                    </button>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}