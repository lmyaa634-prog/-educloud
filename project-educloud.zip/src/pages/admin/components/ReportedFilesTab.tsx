import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

interface ReportRecord {
  id: number;
  file_id: number;
  reason: string;
  status: string;
  created_at: string;
  file_title: string;
  file_college: string | null;
  uploader_name: string | null;
  reporter_name: string | null;
}

export default function ReportedFilesTab({ onStatsChange }: { onStatsChange?: () => void }) {
  const [reports, setReports] = useState<ReportRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<number | null>(null);

  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("reports")
      .select("*, files:file_id(title, college, uploader_id), profiles:reporter_id(full_name)")
      .eq("status", "pending")
      .order("created_at", { ascending: false });

    const mapped: ReportRecord[] = [];
    for (const r of data || []) {
      const fileUploaderId = r.files?.uploader_id;
      let uploaderName = "Unknown";
      if (fileUploaderId) {
        const { data: up } = await supabase
          .from("profiles")
          .select("full_name")
          .eq("id", fileUploaderId)
          .maybeSingle();
        uploaderName = up?.full_name ?? "Unknown";
      }
      mapped.push({
        id: r.id,
        file_id: r.file_id,
        reason: r.reason,
        status: r.status,
        created_at: r.created_at,
        file_title: r.files?.title ?? "Unknown File",
        file_college: r.files?.college ?? null,
        uploader_name: uploaderName,
        reporter_name: r.profiles?.full_name ?? "Anonymous",
      });
    }
    setReports(mapped);
    setLoading(false);
  };

  const handleIgnore = async (id: number) => {
    setProcessing(id);
    await supabase.from("reports").update({ status: "ignored" }).eq("id", id);
    setProcessing(null);
    await loadReports();
    onStatsChange?.();
  };

  const handleDelete = async (id: number, fileId: number) => {
    setProcessing(id);
    await supabase.from("files").update({ status: "deleted" }).eq("id", fileId);
    await supabase.from("reports").update({ status: "resolved" }).eq("id", id);
    setProcessing(null);
    await loadReports();
    onStatsChange?.();
  };

  const pendingCount = reports.length;

  return (
    <div>
      <div className="mb-5">
        <h2 className="font-semibold text-gray-900">Reported Content</h2>
        <p className="text-sm text-gray-500 mt-0.5">
          {pendingCount} report{pendingCount !== 1 ? "s" : ""} pending review
        </p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <i className="ri-loader-4-line animate-spin text-sky-500 text-2xl"></i>
        </div>
      ) : reports.length === 0 ? (
        <div className="bg-white rounded-lg border border-gray-100 p-8 text-center">
          <div className="w-12 h-12 flex items-center justify-center mx-auto mb-3">
            <i className="ri-check-double-line text-gray-300 text-3xl"></i>
          </div>
          <p className="text-sm text-gray-500">No reports to review. All clear!</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {reports.map((report) => (
            <div key={report.id} className="bg-white rounded-lg border border-orange-200 p-4 transition-all">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-5 h-5 flex items-center justify-center">
                      <i className="ri-flag-fill text-orange-500 text-sm"></i>
                    </div>
                    <h3 className="text-sm font-semibold text-gray-900">{report.file_title}</h3>
                  </div>
                  <div className="flex flex-wrap gap-3 mb-2">
                    <span className="text-xs text-gray-500">{report.file_college?.replace("Faculty of ", "") || "General"}</span>
                    <span className="text-xs text-gray-500">Uploaded by: {report.uploader_name}</span>
                  </div>
                  <div className="bg-orange-50 rounded-md px-3 py-2 mb-2">
                    <p className="text-xs text-orange-800">
                      <strong>Report reason:</strong> {report.reason}
                    </p>
                    <p className="text-xs text-orange-600 mt-0.5">
                      Reported by {report.reporter_name} on {new Date(report.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    onClick={() => handleIgnore(report.id)}
                    disabled={processing === report.id}
                    className="px-3 py-1.5 text-xs text-gray-600 border border-gray-200 rounded-md hover:bg-gray-50 cursor-pointer whitespace-nowrap disabled:opacity-50"
                  >
                    Ignore
                  </button>
                  <button
                    onClick={() => handleDelete(report.id, report.file_id)}
                    disabled={processing === report.id}
                    className="px-3 py-1.5 text-xs text-white bg-red-500 hover:bg-red-600 rounded-md cursor-pointer whitespace-nowrap disabled:opacity-50"
                  >
                    {processing === report.id ? (
                      <i className="ri-loader-4-line animate-spin text-xs"></i>
                    ) : (
                      "Delete File"
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}