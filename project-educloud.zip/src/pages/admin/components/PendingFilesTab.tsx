import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

const FILE_TYPE_CONFIG: Record<string, { icon: string; color: string; bg: string }> = {
  pdf: { icon: "ri-file-pdf-line", color: "text-red-600", bg: "bg-red-50" },
  ppt: { icon: "ri-file-ppt-line", color: "text-orange-600", bg: "bg-orange-50" },
  docx: { icon: "ri-file-word-line", color: "text-sky-600", bg: "bg-sky-50" },
  image: { icon: "ri-image-line", color: "text-violet-600", bg: "bg-violet-50" },
  video: { icon: "ri-video-line", color: "text-pink-600", bg: "bg-pink-50" },
};

interface PendingFile {
  id: number;
  title: string;
  file_type: string;
  course_name: string;
  college: string;
  level: number;
  description: string | null;
  views: number;
  created_at: string;
  uploader_id: string;
  uploader_name: string | null;
  uploader_email: string | null;
  uploader_avatar: string | null;
  status: string;
}

export default function PendingFilesTab({ onStatsChange }: { onStatsChange?: () => void }) {
  const [files, setFiles] = useState<PendingFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFile, setSelectedFile] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [showRejectModal, setShowRejectModal] = useState<number | null>(null);
  const [processing, setProcessing] = useState<number | null>(null);

  useEffect(() => {
    loadFiles();
  }, []);

  const loadFiles = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("files")
      .select("*, profiles:uploader_id(full_name, email, avatar)")
      .eq("status", "pending")
      .order("created_at", { ascending: false });

    const mapped: PendingFile[] = (data || []).map((f: any) => ({
      id: f.id,
      title: f.title,
      file_type: f.file_type,
      course_name: f.course_name,
      college: f.college,
      level: f.level,
      description: f.description,
      views: f.views ?? 0,
      created_at: f.created_at,
      uploader_id: f.uploader_id,
      uploader_name: f.profiles?.full_name ?? "Unknown",
      uploader_email: f.profiles?.email ?? "",
      uploader_avatar: f.profiles?.avatar ?? null,
      status: f.status,
    }));
    setFiles(mapped);
    setLoading(false);
  };

  const handleApprove = async (id: number) => {
    setProcessing(id);
    await supabase.from("files").update({ status: "approved" }).eq("id", id);
    setProcessing(null);
    setSelectedFile(null);
    await loadFiles();
    onStatsChange?.();
  };

  const handleReject = async (id: number) => {
    setProcessing(id);
    await supabase.from("files").update({ status: "rejected" }).eq("id", id);
    setProcessing(null);
    setShowRejectModal(null);
    setRejectReason("");
    await loadFiles();
    onStatsChange?.();
  };

  const pendingCount = files.length;

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="font-semibold text-gray-900">Pending Files</h2>
          <p className="text-sm text-gray-500 mt-0.5">
            {pendingCount} file{pendingCount !== 1 ? "s" : ""} awaiting review
          </p>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <i className="ri-loader-4-line animate-spin text-sky-500 text-2xl"></i>
        </div>
      ) : files.length === 0 ? (
        <div className="bg-white rounded-lg border border-gray-100 p-8 text-center">
          <div className="w-12 h-12 flex items-center justify-center mx-auto mb-3">
            <i className="ri-check-double-line text-gray-300 text-3xl"></i>
          </div>
          <p className="text-sm text-gray-500">No pending files to review. All caught up!</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {files.map((file) => {
            const typeConfig = FILE_TYPE_CONFIG[file.file_type] || FILE_TYPE_CONFIG.pdf;
            const isSelected = selectedFile === file.id;

            return (
              <div key={file.id} className="bg-white rounded-lg border border-gray-100 hover:border-gray-200 transition-all">
                <div className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={`w-10 h-10 flex items-center justify-center rounded-lg flex-shrink-0 ${typeConfig.bg}`}>
                      <i className={`${typeConfig.icon} ${typeConfig.color} text-lg`}></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div>
                          <h3 className="text-sm font-semibold text-gray-900">{file.title}</h3>
                          <p className="text-xs text-gray-500 mt-0.5">{file.description || "No description provided."}</p>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <button
                            onClick={() => setSelectedFile(isSelected ? null : file.id)}
                            className="px-3 py-1.5 text-xs text-gray-600 border border-gray-200 rounded-md hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                          >
                            {isSelected ? "Hide" : "Preview"}
                          </button>
                          <button
                            onClick={() => setShowRejectModal(file.id)}
                            disabled={processing === file.id}
                            className="px-3 py-1.5 text-xs text-red-600 border border-red-200 rounded-md hover:bg-red-50 cursor-pointer whitespace-nowrap disabled:opacity-50"
                          >
                            Reject
                          </button>
                          <button
                            onClick={() => handleApprove(file.id)}
                            disabled={processing === file.id}
                            className="px-3 py-1.5 text-xs text-white bg-sky-500 hover:bg-sky-600 rounded-md cursor-pointer whitespace-nowrap disabled:opacity-50"
                          >
                            {processing === file.id ? (
                              <i className="ri-loader-4-line animate-spin text-xs"></i>
                            ) : (
                              "Approve"
                            )}
                          </button>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-3 mt-2">
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <i className="ri-book-open-line text-xs text-gray-400"></i>
                          {file.course_name}
                        </span>
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <i className="ri-building-line text-xs text-gray-400"></i>
                          {file.college?.replace("Faculty of ", "") || "General"}
                        </span>
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <i className="ri-graduation-cap-line text-xs text-gray-400"></i>
                          Year {file.level}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 mt-2">
                        {file.uploader_avatar ? (
                          <img src={file.uploader_avatar} alt={file.uploader_name || ""} className="w-5 h-5 rounded-full object-cover object-top" />
                        ) : (
                          <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-[10px] font-semibold text-gray-500">
                            {(file.uploader_name || "U").charAt(0).toUpperCase()}
                          </div>
                        )}
                        <span className="text-xs text-gray-600">{file.uploader_name}</span>
                        <span className="text-xs text-gray-400">{file.uploader_email}</span>
                        <span className="text-xs text-gray-400 ml-auto">Submitted {new Date(file.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Preview */}
                  {isSelected && (
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <div className="bg-gray-50 rounded-lg p-4 text-center">
                        <div className={`w-12 h-12 flex items-center justify-center rounded-xl mx-auto mb-2 ${typeConfig.bg}`}>
                          <i className={`${typeConfig.icon} ${typeConfig.color} text-2xl`}></i>
                        </div>
                        <p className="text-sm text-gray-600">{file.title}</p>
                        <p className="text-xs text-gray-400 mt-1">File preview requires Supabase Storage connection</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Reject Modal */}
      {showRejectModal !== null && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-gray-900">Reject File</h4>
              <button onClick={() => setShowRejectModal(null)} className="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-gray-600 cursor-pointer">
                <i className="ri-close-line text-lg"></i>
              </button>
            </div>
            <p className="text-sm text-gray-600 mb-4">Please provide a reason for rejection (optional):</p>
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value.slice(0, 300))}
              placeholder="e.g. Content is incomplete, incorrect information, copyright issue..."
              rows={3}
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-red-400 resize-none mb-4"
            />
            <div className="flex gap-2">
              <button
                onClick={() => setShowRejectModal(null)}
                className="flex-1 py-2 border border-gray-200 text-gray-700 text-sm rounded-md hover:bg-gray-50 cursor-pointer whitespace-nowrap"
              >
                Cancel
              </button>
              <button
                onClick={() => handleReject(showRejectModal)}
                disabled={processing === showRejectModal}
                className="flex-1 py-2 bg-red-500 hover:bg-red-600 disabled:opacity-60 text-white text-sm font-medium rounded-md cursor-pointer whitespace-nowrap"
              >
                Confirm Reject
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}