import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import PendingFilesTab from "./components/PendingFilesTab";
import ReportedFilesTab from "./components/ReportedFilesTab";
import UsersTab from "./components/UsersTab";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/context/AuthContext";

type AdminTab = "pending" | "reported" | "users";

interface AdminStats {
  totalFiles: number;
  pendingFiles: number;
  reportedFiles: number;
  totalUsers: number;
  bannedUsers: number;
  approvedToday: number;
}

export default function AdminDashboardPage() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<AdminTab>("pending");
  const [stats, setStats] = useState<AdminStats>({
    totalFiles: 0,
    pendingFiles: 0,
    reportedFiles: 0,
    totalUsers: 0,
    bannedUsers: 0,
    approvedToday: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/login");
      return;
    }
    if (!authLoading && user && user.role !== "admin") {
      navigate("/");
      return;
    }
  }, [authLoading, user, navigate]);

  useEffect(() => {
    const loadStats = async () => {
      setLoading(true);

      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayIso = todayStart.toISOString();

      const [filesRes, pendingRes, reportsRes, usersRes, bannedRes, approvedRes] = await Promise.all([
        supabase.from("files").select("id", { count: "exact", head: true }),
        supabase.from("files").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("reports").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("profiles").select("id", { count: "exact", head: true }).eq("status", "banned"),
        supabase.from("files").select("id", { count: "exact", head: true }).eq("status", "approved").gte("updated_at", todayIso),
      ]);

      setStats({
        totalFiles: filesRes.count ?? 0,
        pendingFiles: pendingRes.count ?? 0,
        reportedFiles: reportsRes.count ?? 0,
        totalUsers: usersRes.count ?? 0,
        bannedUsers: bannedRes.count ?? 0,
        approvedToday: approvedRes.count ?? 0,
      });
      setLoading(false);
    };

    loadStats();
  }, []);

  const refreshStats = async () => {
    const [pendingRes, reportsRes, usersRes, bannedRes] = await Promise.all([
      supabase.from("files").select("id", { count: "exact", head: true }).eq("status", "pending"),
      supabase.from("reports").select("id", { count: "exact", head: true }).eq("status", "pending"),
      supabase.from("profiles").select("id", { count: "exact", head: true }),
      supabase.from("profiles").select("id", { count: "exact", head: true }).eq("status", "banned"),
    ]);
    setStats((s) => ({
      ...s,
      pendingFiles: pendingRes.count ?? 0,
      reportedFiles: reportsRes.count ?? 0,
      totalUsers: usersRes.count ?? 0,
      bannedUsers: bannedRes.count ?? 0,
    }));
  };

  const tabs: { id: AdminTab; label: string; icon: string; badge?: number }[] = [
    { id: "pending", label: "Pending Files", icon: "ri-time-line", badge: stats.pendingFiles },
    { id: "reported", label: "Reported Content", icon: "ri-flag-line", badge: stats.reportedFiles },
    { id: "users", label: "Users", icon: "ri-user-line" },
  ];

  const statsCards = [
    { label: "Total Files", value: stats.totalFiles.toLocaleString("en-US"), icon: "ri-file-text-line", color: "text-sky-500", bg: "bg-sky-50" },
    { label: "Pending Review", value: String(stats.pendingFiles), icon: "ri-time-line", color: "text-amber-600", bg: "bg-amber-50" },
    { label: "Reported", value: String(stats.reportedFiles), icon: "ri-flag-line", color: "text-red-500", bg: "bg-red-50" },
    { label: "Total Users", value: stats.totalUsers.toLocaleString("en-US"), icon: "ri-user-line", color: "text-sky-600", bg: "bg-sky-50" },
    { label: "Approved Today", value: String(stats.approvedToday), icon: "ri-checkbox-circle-fill", color: "text-sky-600", bg: "bg-sky-50" },
    { label: "Banned Users", value: String(stats.bannedUsers), icon: "ri-user-forbid-line", color: "text-red-500", bg: "bg-red-50" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Navbar */}
      <nav className="bg-sky-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 md:px-6 flex items-center justify-between h-14">
          <div className="flex items-center gap-3">
            <img
              src="https://public.readdy.ai/ai/img_res/517a6f4d-1e10-4e46-942d-0f5ba7c98043.png"
              alt="StudyHub"
              className="h-8 w-auto object-contain brightness-0 invert"
            />
            <span className="text-white/60 text-sm">|</span>
            <span className="text-white text-sm font-medium">Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/" className="text-sky-200 hover:text-white text-sm transition-colors cursor-pointer">
              View Site
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 flex items-center justify-center bg-sky-700 rounded-full">
                <i className="ri-shield-user-line text-sky-200 text-sm"></i>
              </div>
              <span className="text-white text-sm">Admin</span>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Manage files, reports, and users across the platform.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
          {statsCards.map((stat) => (
            <div key={stat.label} className="bg-white rounded-lg border border-gray-100 p-4">
              <div className={`w-8 h-8 flex items-center justify-center rounded-lg mb-2 ${stat.bg}`}>
                <i className={`${stat.icon} ${stat.color} text-sm`}></i>
              </div>
              <p className="text-xl font-bold text-gray-900">{loading ? "—" : stat.value}</p>
              <p className="text-xs text-gray-500 mt-0.5">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 border-b border-gray-200 mb-6">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors cursor-pointer whitespace-nowrap -mb-px ${
                activeTab === tab.id
                  ? "border-sky-500 text-sky-700"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              <i className={`${tab.icon} text-sm`}></i>
              {tab.label}
              {tab.badge !== undefined && tab.badge > 0 && (
                <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${
                  activeTab === tab.id ? "bg-sky-100 text-sky-700" : "bg-gray-100 text-gray-600"
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === "pending" && <PendingFilesTab onStatsChange={refreshStats} />}
        {activeTab === "reported" && <ReportedFilesTab onStatsChange={refreshStats} />}
        {activeTab === "users" && <UsersTab onStatsChange={refreshStats} />}
      </div>
    </div>
  );
}