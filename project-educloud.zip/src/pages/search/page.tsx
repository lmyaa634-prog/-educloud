import { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import Navbar from "@/components/feature/Navbar";
import { supabase } from "@/lib/supabase";
import { formatLevel } from "@/lib/helpers";
import { COLLEGES, LEVELS, YEARS } from "@/mocks/searchData";

const FILE_TYPE_CONFIG: Record<string, { icon: string; color: string; bg: string }> = {
  pdf: { icon: "ri-file-pdf-line", color: "text-red-600", bg: "bg-red-50" },
  ppt: { icon: "ri-file-ppt-line", color: "text-orange-600", bg: "bg-orange-50" },
  docx: { icon: "ri-file-word-line", color: "text-sky-600", bg: "bg-sky-50" },
  image: { icon: "ri-image-line", color: "text-violet-600", bg: "bg-violet-50" },
  video: { icon: "ri-video-line", color: "text-pink-600", bg: "bg-pink-50" },
};

interface SearchFile {
  id: number;
  title: string;
  description: string | null;
  file_type: string;
  course_name: string;
  instructor_name: string | null;
  college: string | null;
  year: number | null;
  level: number | null;
  stars_avg: number | null;
  likes: number;
  views: number;
  created_at: string;
  uploader_name: string | null;
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <div key={star} className="w-3 h-3 flex items-center justify-center">
          <i
            className={`${
              star <= Math.round(rating) ? "ri-star-fill" : "ri-star-line"
            } text-amber-400 text-xs`}
          ></i>
        </div>
      ))}
    </div>
  );
}

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get("q") || "");
  const [filters, setFilters] = useState({
    college: "",
    level: "",
    year: "",
    fileType: "",
  });
  const [sortBy, setSortBy] = useState("popular");
  const [showFilters, setShowFilters] = useState(true);
  const [results, setResults] = useState<SearchFile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = searchParams.get("q");
    if (q) setQuery(q);
  }, [searchParams]);

  useEffect(() => {
    loadFiles();
  }, [searchParams, sortBy, filters]);

  const loadFiles = async () => {
    setLoading(true);

    let dbQuery = supabase
      .from("files")
      .select("*, profiles:uploader_id(full_name)")
      .eq("status", "approved");

    if (filters.college) {
      dbQuery = dbQuery.eq("college", filters.college);
    }
    if (filters.fileType) {
      dbQuery = dbQuery.eq("file_type", filters.fileType);
    }
    if (filters.year) {
      const yearNum = parseInt(filters.year, 10);
      if (!Number.isNaN(yearNum)) dbQuery = dbQuery.eq("year", yearNum);
    }
    if (filters.level) {
      const levelNum = parseInt(filters.level, 10);
      if (!Number.isNaN(levelNum)) dbQuery = dbQuery.eq("level", levelNum);
    }

    const q = query.trim().toLowerCase();
    if (q) {
      dbQuery = dbQuery.or(
        `title.ilike.%${q}%,course_name.ilike.%${q}%,instructor_name.ilike.%${q}%,college.ilike.%${q}%,description.ilike.%${q}%`
      );
    }

    if (sortBy === "popular") dbQuery = dbQuery.order("views", { ascending: false });
    else if (sortBy === "rating") dbQuery = dbQuery.order("stars_avg", { ascending: false });
    else if (sortBy === "recent") dbQuery = dbQuery.order("created_at", { ascending: false });
    else dbQuery = dbQuery.order("views", { ascending: false });

    dbQuery = dbQuery.limit(50);

    const { data, error } = await dbQuery;

    if (error) {
      setResults([]);
      setLoading(false);
      return;
    }

    const mapped: SearchFile[] = (data || []).map((f: any) => ({
      id: f.id,
      title: f.title,
      description: f.description,
      file_type: f.file_type,
      course_name: f.course_name,
      instructor_name: f.instructor_name,
      college: f.college,
      year: f.year,
      level: f.level,
      stars_avg: f.stars_avg,
      likes: f.likes ?? 0,
      views: f.views ?? 0,
      created_at: f.created_at,
      uploader_name: f.profiles?.full_name ?? "Unknown",
    }));

    setResults(mapped);
    setLoading(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams(query ? { q: query } : {});
  };

  const setFilter = (key: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [key]: prev[key as keyof typeof prev] === value ? "" : value,
    }));
  };

  const clearFilters = () => {
    setFilters({ college: "", level: "", year: "", fileType: "" });
  };

  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Search Header */}
      <div className="bg-sky-600 py-8">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <h1 className="text-white font-bold text-2xl mb-4">Search Academic Materials</h1>
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="flex-1 relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                <i className="ri-search-line text-gray-400 text-sm"></i>
              </div>
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by course, instructor, topic..."
                className="w-full pl-11 pr-4 py-3 text-sm bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-300 text-gray-800"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 bg-sky-500 hover:bg-sky-400 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              Search
            </button>
          </form>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Filters */}
          <aside className={`w-full lg:w-64 flex-shrink-0 ${showFilters ? "block" : "hidden lg:block"}`}>
            <div className="bg-white rounded-lg border border-gray-100 p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900 text-sm">Filters</h3>
                {activeFilterCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="text-xs text-sky-500 hover:text-sky-600 cursor-pointer"
                  >
                    Clear all ({activeFilterCount})
                  </button>
                )}
              </div>

              {/* File Type */}
              <div className="mb-5">
                <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                  File Type
                </h4>
                <div className="flex flex-col gap-1.5">
                  {["pdf", "ppt", "docx", "image", "video"].map((type) => {
                    const cfg = FILE_TYPE_CONFIG[type];
                    return (
                      <button
                        key={type}
                        onClick={() => setFilter("fileType", type)}
                        className={`flex items-center gap-2 px-3 py-2 rounded-md text-xs transition-colors cursor-pointer text-left ${
                          filters.fileType === type
                            ? "bg-sky-50 text-sky-700 border border-sky-200"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <div className={`w-5 h-5 flex items-center justify-center rounded ${cfg.bg}`}>
                          <i className={`${cfg.icon} ${cfg.color} text-xs`}></i>
                        </div>
                        {type.toUpperCase()}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* College */}
              <div className="mb-5">
                <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">College</h4>
                <div className="flex flex-col gap-1">
                  {COLLEGES.map((c) => (
                    <button
                      key={c}
                      onClick={() => setFilter("college", c)}
                      className={`flex items-center gap-2 px-2 py-1.5 rounded text-xs text-left transition-colors cursor-pointer ${
                        filters.college === c ? "text-sky-700 font-medium" : "text-gray-600 hover:text-gray-900"
                      }`}
                    >
                      <div
                        className={`w-3 h-3 rounded-full border flex-shrink-0 flex items-center justify-center ${
                          filters.college === c ? "border-sky-500 bg-sky-500" : "border-gray-300"
                        }`}
                      >
                        {filters.college === c && (
                          <i className="ri-check-line text-white" style={{ fontSize: "8px" }}></i>
                        )}
                      </div>
                      {c.replace("Faculty of ", "")}
                    </button>
                  ))}
                </div>
              </div>

              {/* Level */}
              <div className="mb-5">
                <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                  Academic Level
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {LEVELS.map((l) => {
                    const num = parseInt(l, 10);
                    return (
                      <button
                        key={l}
                        onClick={() => setFilter("level", String(num))}
                        className={`px-2.5 py-1 rounded-full text-xs transition-colors cursor-pointer whitespace-nowrap ${
                          filters.level === String(num)
                            ? "bg-sky-500 text-white"
                            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                        }`}
                      >
                        {l}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Year */}
              <div className="mb-5">
                <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Year</h4>
                <div className="flex flex-wrap gap-1.5">
                  {YEARS.map((y) => (
                    <button
                      key={y}
                      onClick={() => setFilter("year", String(y))}
                      className={`px-2.5 py-1 rounded-full text-xs transition-colors cursor-pointer whitespace-nowrap ${
                        filters.year === String(y)
                          ? "bg-sky-500 text-white"
                          : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                      }`}
                    >
                      {y}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Results */}
          <div className="flex-1 min-w-0">
            {/* Results Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="lg:hidden flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-md text-xs text-gray-600 hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-filter-line text-xs"></i>
                  Filters {activeFilterCount > 0 && `(${activeFilterCount})`}
                </button>
                <p className="text-sm text-gray-600">
                  <strong className="text-gray-900">{results.length}</strong> results
                  {query && (
                    <span>
                      {" "}
                      for &ldquo;<span className="text-sky-600">{query}</span>&rdquo;
                    </span>
                  )}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="text-xs border border-gray-200 rounded-md px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-sky-400 cursor-pointer bg-white"
                >
                  <option value="popular">Most Popular</option>
                  <option value="rating">Highest Rated</option>
                  <option value="recent">Most Recent</option>
                </select>
              </div>
            </div>

            {/* Active Filters */}
            {activeFilterCount > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {Object.entries(filters).map(([key, val]) =>
                  val ? (
                    <span
                      key={key}
                      className="inline-flex items-center gap-1 px-2.5 py-1 bg-sky-50 text-sky-700 rounded-full text-xs border border-sky-200"
                    >
                      {val}
                      <button
                        onClick={() => setFilter(key, val)}
                        className="w-3 h-3 flex items-center justify-center cursor-pointer hover:text-sky-900"
                      >
                        <i className="ri-close-line text-xs"></i>
                      </button>
                    </span>
                  ) : null
                )}
              </div>
            )}

            {/* Results List */}
            {loading ? (
              <div className="flex items-center justify-center py-20 bg-white rounded-lg border border-gray-100">
                <div className="flex items-center gap-2 text-gray-400">
                  <i className="ri-loader-4-line animate-spin text-xl"></i>
                  <span className="text-sm">Loading files...</span>
                </div>
              </div>
            ) : results.length > 0 ? (
              <div className="flex flex-col gap-3">
                {results.map((file) => {
                  const typeConfig = FILE_TYPE_CONFIG[file.file_type] || FILE_TYPE_CONFIG.pdf;
                  const rating =
                    Number.isFinite(file.stars_avg) && file.stars_avg ? file.stars_avg : 0;
                  return (
                    <Link
                      key={file.id}
                      to={`/file/${file.id}`}
                      className="group bg-white rounded-lg border border-gray-100 hover:border-sky-200 transition-all cursor-pointer block"
                    >
                      <div className="flex gap-4 p-4">
                        <div className="w-16 h-16 flex-shrink-0 rounded-md flex items-center justify-center bg-gray-50">
                          <i className={`${typeConfig.icon} ${typeConfig.color} text-2xl`}></i>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <h3 className="text-sm font-semibold text-gray-900 group-hover:text-sky-600 transition-colors line-clamp-1">
                              {file.title}
                            </h3>
                            <span
                              className={`flex-shrink-0 inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium ${typeConfig.bg} ${typeConfig.color}`}
                            >
                              {file.file_type.toUpperCase()}
                            </span>
                          </div>
                          {file.description && (
                            <p className="text-xs text-gray-500 mb-2 line-clamp-1">{file.description}</p>
                          )}
                          <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500">
                            <span className="flex items-center gap-1">
                              <i className="ri-book-open-line text-xs"></i>
                              {file.course_name}
                            </span>
                            {file.instructor_name && (
                              <span className="flex items-center gap-1">
                                <i className="ri-user-line text-xs"></i>
                                {file.instructor_name}
                              </span>
                            )}
                            {file.college && (
                              <span className="flex items-center gap-1">
                                <i className="ri-building-line text-xs"></i>
                                {file.college.replace("Faculty of ", "")}
                              </span>
                            )}
                            {file.level !== null && (
                              <span className="flex items-center gap-1">
                                <i className="ri-graduation-cap-line text-xs"></i>
                                {formatLevel(file.level)}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-3 mt-2">
                            <div className="flex items-center gap-1">
                              <StarRating rating={rating} />
                              <span className="text-xs font-medium text-gray-700">
                                {Number.isFinite(rating) ? rating.toFixed(1) : "0.0"}
                              </span>
                            </div>
                            <span className="flex items-center gap-1 text-xs text-gray-400">
                              <i className="ri-download-line text-xs"></i>
                              {file.views >= 1000 ? `${(file.views / 1000).toFixed(1)}k` : file.views}
                            </span>
                            <span className="flex items-center gap-1 text-xs text-gray-400">
                              <i className="ri-heart-line text-xs"></i>
                              {file.likes}
                            </span>
                          </div>
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-20 bg-white rounded-lg border border-gray-100">
                <div className="w-14 h-14 flex items-center justify-center mx-auto mb-4 bg-gray-50 rounded-full">
                  <i className="ri-search-line text-gray-300 text-2xl"></i>
                </div>
                <h3 className="text-gray-700 font-medium mb-1">No results found</h3>
                <p className="text-gray-400 text-sm">Try different keywords or adjust your filters.</p>
                {activeFilterCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="mt-4 px-4 py-2 text-sm text-sky-500 border border-sky-200 rounded-md hover:bg-sky-50 cursor-pointer whitespace-nowrap"
                  >
                    Clear Filters
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}