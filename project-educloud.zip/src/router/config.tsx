import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import LoginPage from "../pages/login/page";
import RegisterPage from "../pages/register/page";
import SearchPage from "../pages/search/page";
import FileViewPage from "../pages/fileview/page";
import UploadPage from "../pages/upload/page";
import ProfilePage from "../pages/profile/page";
import AdminDashboardPage from "../pages/admin/page";
import PrivacyPolicyPage from "../pages/privacy/page";
import TermsPage from "../pages/terms/page";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    path: "/register",
    element: <RegisterPage />,
  },
  {
    path: "/search",
    element: <SearchPage />,
  },
  {
    path: "/file/:id",
    element: <FileViewPage />,
  },
  {
    path: "/upload",
    element: <UploadPage />,
  },
  {
    path: "/profile",
    element: <ProfilePage />,
  },
  {
    path: "/admin",
    element: <AdminDashboardPage />,
  },
  {
    path: "/privacy",
    element: <PrivacyPolicyPage />,
  },
  {
    path: "/terms",
    element: <TermsPage />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;