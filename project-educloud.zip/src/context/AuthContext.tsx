import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { supabase, type Profile } from "@/lib/supabase";

interface AuthContextType {
  user: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error?: string; role?: string }>;
  signUp: (email: string, password: string, profileData: Partial<Profile>) => Promise<{ error?: string }>;
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const userRef = useRef<Profile | null>(null);
  const fetchingRef = useRef(false);

  useEffect(() => {
    userRef.current = user;
  }, [user]);

  const fetchProfile = async (userId: string): Promise<{ profile: Profile | null; error?: string }> => {
    const delays = [300, 500, 800, 1200, 2000];

    for (let attempt = 0; attempt < delays.length; attempt++) {
      // Validate session exists and is usable
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) {
        const msg = `Session error (attempt ${attempt + 1}): ${sessionError.message}`;
        if (attempt < delays.length - 1) {
          await new Promise((r) => setTimeout(r, delays[attempt]));
          continue;
        }
        return { profile: null, error: msg };
      }

      if (!sessionData.session) {
        if (attempt < delays.length - 1) {
          await new Promise((r) => setTimeout(r, delays[attempt]));
          continue;
        }
        return { profile: null, error: "No active session found. Please sign in again." };
      }

      // Also validate the user object is present (extra safety)
      const { data: userData, error: userError } = await supabase.auth.getUser();
      if (userError || !userData.user) {
        if (attempt < delays.length - 1) {
          await new Promise((r) => setTimeout(r, delays[attempt]));
          continue;
        }
        return { profile: null, error: "Session validation failed. Please sign in again." };
      }

      // Now query the profile with the confirmed session
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", userId)
        .maybeSingle();

      if (error) {
        const msg = `Database error (attempt ${attempt + 1}): ${error.message}`;
        if (attempt < delays.length - 1) {
          await new Promise((r) => setTimeout(r, delays[attempt]));
          continue;
        }
        return { profile: null, error: msg };
      }

      if (data) {
        setUser(data as Profile);
        return { profile: data as Profile };
      }

      if (attempt < delays.length - 1) {
        await new Promise((r) => setTimeout(r, delays[attempt]));
        continue;
      }

      return { profile: null, error: "Profile not found in database after multiple attempts." };
    }

    return { profile: null, error: "Could not load profile after multiple attempts." };
  };

  useEffect(() => {
    let mounted = true;

    const init = async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session?.user && mounted && !fetchingRef.current) {
        fetchingRef.current = true;
        await fetchProfile(data.session.user.id);
        fetchingRef.current = false;
      }
      if (mounted) setLoading(false);
    };

    init();

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!mounted) return;

      if (session?.user) {
        if (!userRef.current || userRef.current.id !== session.user.id) {
          if (!fetchingRef.current) {
            fetchingRef.current = true;
            fetchProfile(session.user.id).finally(() => {
              fetchingRef.current = false;
            });
          }
        }
      } else {
        setUser(null);
      }
    });

    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { error: error.message };

    const uid = data.user?.id;
    if (!uid) return { error: "Login succeeded but no user ID found." };

    // Explicitly bind the session into the client so RLS queries work immediately
    if (data.session) {
      await supabase.auth.setSession({
        access_token: data.session.access_token,
        refresh_token: data.session.refresh_token,
      });
    }

    // Give the client time to propagate the auth headers internally
    await new Promise((r) => setTimeout(r, 800));

    const { profile, error: profileError } = await fetchProfile(uid);
    if (profileError || !profile) {
      return { error: profileError || "Could not load your profile. Please try again." };
    }

    return { role: profile.role };
  };

  const signUp = async (email: string, password: string, profileData: Partial<Profile>) => {
    const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: profileData.full_name || "",
          college: profileData.college || null,
        },
      },
    });

    if (signUpError) return { error: signUpError.message };

    const uid = signUpData.user?.id;
    if (!uid) return { error: "Registration failed — no user ID returned." };

    // Attempt auto-login after registration
    const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (signInError || !signInData.session) {
      // Email confirmation is required — user must verify email before signing in
      return {};
    }

    // Bind session and load profile
    await supabase.auth.setSession({
      access_token: signInData.session.access_token,
      refresh_token: signInData.session.refresh_token,
    });

    await new Promise((r) => setTimeout(r, 800));
    await fetchProfile(uid);
    return {};
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  const refreshUser = async () => {
    const { data } = await supabase.auth.getSession();
    if (data.session?.user) {
      await fetchProfile(data.session.user.id);
    } else {
      setUser(null);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}