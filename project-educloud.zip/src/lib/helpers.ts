import { supabase } from "./supabase";

export function getStoragePublicUrl(filePath: string): string {
  const url = import.meta.env.VITE_PUBLIC_SUPABASE_URL;
  return `${url}/storage/v1/object/public/file_storage/${filePath}`;
}

export function formatLevel(level: number | null | string): string {
  if (level === null || level === undefined || level === "") return "—";
  const n = typeof level === "string" ? parseInt(level, 10) : level;
  if (Number.isNaN(n)) return String(level);
  const suffixes: Record<number, string> = {
    1: "1st Year",
    2: "2nd Year",
    3: "3rd Year",
    4: "4th Year",
    5: "5th Year",
    6: "Postgraduate",
  };
  return suffixes[n] || `${n}th Year`;
}

export function formatDate(ts: string | null): string {
  if (!ts) return "";
  return new Date(ts).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export async function getFileDownloadUrl(filePath: string): Promise<string | null> {
  const { data } = await supabase.storage.from("file_storage").createSignedUrl(filePath, 60 * 60);
  return data?.signedUrl ?? null;
}