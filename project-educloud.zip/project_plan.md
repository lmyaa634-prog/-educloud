# Self-Learning Platform

## 1. Project Description
A cloud-based academic file sharing platform for university students. Students can upload, share, search, rate, and comment on academic materials (lectures, summaries, revision files). Solves the problem of scattered files across WhatsApp/Telegram by providing one organized, searchable, quality-controlled hub. Admins must approve every file before it becomes visible to students.

**Target Users:** University students and academic administrators  
**Core Value:** Centralized, organized, quality-controlled academic resource sharing

---

## 2. Page Structure
- `/` - Home Page (popular & recent files)
- `/login` - Login Page
- `/register` - Register Page
- `/search` - Search & Filter Page
- `/file/:id` - File View Page (inline viewer + rating + comments)
- `/upload` - Upload Page
- `/profile` - Profile Page (uploads, favorites, history)
- `/admin` - Admin Dashboard (approve/reject/delete/ban)

---

## 3. Core Features
- [ ] User authentication (login / register)
- [ ] File upload (PDF, PPT, DOCX, image, video)
- [ ] File metadata (course, instructor, college, year, level)
- [ ] Admin approval workflow (pending → approved/rejected)
- [ ] Inline file viewer (no download required)
- [ ] Advanced search & filter (college, year, level, course, instructor)
- [ ] Rating system (1–5 stars + likes)
- [ ] Comments section per file
- [ ] Save to favorites
- [ ] Most popular / most recent sections on homepage
- [ ] File reporting system
- [ ] Admin dashboard (approve, reject, delete, ban users)
- [ ] Responsive design (desktop, tablet, mobile)

---

## 4. Data Model Design
(Supabase required for full functionality)

### Table: users
| Field | Type | Description |
|-------|------|-------------|
| id | uuid | Primary key |
| name | text | Full name |
| email | text | Unique email |
| role | text | 'student' or 'admin' |
| avatar_url | text | Profile picture |
| is_banned | boolean | Ban status |
| created_at | timestamp | Registration date |

### Table: files
| Field | Type | Description |
|-------|------|-------------|
| id | uuid | Primary key |
| uploader_id | uuid | FK → users.id |
| title | text | File title |
| description | text | Short description |
| file_url | text | Storage URL |
| file_type | text | pdf/ppt/docx/image/video |
| course_name | text | Course name |
| instructor | text | Instructor name |
| college | text | College/faculty |
| year | int | Academic year |
| level | text | Academic level |
| status | text | pending/approved/rejected |
| downloads | int | Download count |
| created_at | timestamp | Upload date |

### Table: ratings
| Field | Type | Description |
|-------|------|-------------|
| id | uuid | Primary key |
| file_id | uuid | FK → files.id |
| user_id | uuid | FK → users.id |
| stars | int | 1–5 |
| liked | boolean | Like flag |

### Table: comments
| Field | Type | Description |
|-------|------|-------------|
| id | uuid | Primary key |
| file_id | uuid | FK → files.id |
| user_id | uuid | FK → users.id |
| content | text | Comment text |
| created_at | timestamp | Timestamp |

### Table: favorites
| Field | Type | Description |
|-------|------|-------------|
| id | uuid | Primary key |
| user_id | uuid | FK → users.id |
| file_id | uuid | FK → files.id |

### Table: reports
| Field | Type | Description |
|-------|------|-------------|
| id | uuid | Primary key |
| file_id | uuid | FK → files.id |
| reporter_id | uuid | FK → users.id |
| reason | text | Report reason |
| created_at | timestamp | Timestamp |

---

## 5. Backend / Third-party Integration Plan
- **Supabase**: Required for Auth (login/register), Database (all tables above), Storage (file uploads), and Row Level Security
- **Shopify**: Not needed
- **Stripe**: Not needed

---

## 6. Development Phase Plan

### Phase 1: Core UI — Login, Register, Home Pages ✅
- Goal: Build the visual foundation with mock data
- Deliverable: Login page, Register page, Home page with navbar and mock file cards

### Phase 2: Search & File View Pages
- Goal: Search/filter UI + inline file viewer with rating & comments
- Deliverable: Search page with filters, File view page with mock viewer

### Phase 3: Upload & Profile Pages
- Goal: Upload form + user profile page
- Deliverable: Upload page with metadata form, Profile page with tabs

### Phase 4: Admin Dashboard
- Goal: Admin review interface
- Deliverable: Admin dashboard with pending files, reports, user management

### Phase 5: Supabase Integration
- Goal: Connect real backend (auth, database, storage)
- Deliverable: Fully functional platform with real data
